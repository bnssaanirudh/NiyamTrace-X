# NiyamTrace-X - Final Research Artifact Package

This directory consolidates the manuscript, experiment notebooks, retained result archives, recovered frozen evidence, external-validation attempts, and the final merged evidence state.

## Current scientific status

The manuscript is final **for the evidence currently available**. The strongest supported claims are internal/frozen: the 2,000-case multilingual holdout, frozen-runtime ablation, Anchor Lock V3 hardening, and the Verified Execution Broker V2 reference stress test. External validation is **partial**, not complete.

The targeted tau3 QUICK recovery contributes six native trajectories:

| Model | Airline | Retail | Telecom | Mean |
|---|---:|---:|---:|---:|
| Qwen | 1.0 | 0.0 | 0.0 | 0.33 |
| GPT-OSS | 1.0 | 1.0 | 0.0 | 0.67 |

This is one task per domain/model and only two completed model families, so it must **not** be described as full tau3 benchmark performance or three-family external generalization.

BFCL, AgentDojo, MLCL, Agent-SafetyBench, and three-family external generalization remain unsupported by valid retained benchmark-native scores.

## Directory layout

- `paper/pdfs/` - current-evidence IEEE, Springer/LNCS, and Elsevier PDFs.
- `paper/source/` - clean LaTeX source for all three formats.
- `notebooks/stage_01_15/` - staged research notebooks, including fixed variants and master runners.
- `notebooks/external_validation/` - later external-only and completion notebooks.
- `results/stage_results/` - results associated with stages 01-13 and the Wave-3 master run.
- `results/external_validation/` - retained external quick runs, configured master runs, recovery run, and paper-finisher archive.
- `results/frozen_evidence/` - recovered frozen raw evidence and runtime source.
- `results/final_merged/` - latest merged evidence/claim status, including the tau3 recovery.
- `provenance/` - notebook/result map, claim status, notebook checks, PDF hashes, and full SHA-256 manifest.
- `archive/paper_evolution/` - older paper-source snapshots retained only for provenance.

## What to cite/use as final

Use the PDFs under `paper/pdfs/` and the source under `paper/source/`. For quantitative evidence, use `results/final_merged/` plus the stage-specific archives referenced by `provenance/NOTEBOOK_RESULT_MAP.csv`.

Do not use the following as final claims:

- VEB v1 security as proof of complete mediation: it was superseded after the TOCTOU/phantom-row issue.
- SIL/IIEA full=100% as independent empirical accuracy: it is partly rule/property validation.
- Risk-calibrated authorization as a deterministic safety guarantee: repeated splits were unstable.
- Failed/cached external runs as benchmark scores.
- The six tau3 QUICK trajectories as a full benchmark or three-family generalization result.

## Build the papers

Each source directory contains `main.tex`, `abstract.tex`, `body.tex`, `references.bib`, `main.bbl`, and figures. A standard TeX Live installation can rebuild with repeated `pdflatex` passes (or the venue's preferred BibTeX workflow).

Example:

```bash
cd paper/source/ieee
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

## GitHub upload

The files in this package are small enough for a normal repository at the time this bundle was generated. If later raw trajectories/models grow beyond GitHub's normal file limits, move large raw artifacts to Git LFS or a release asset and keep the SHA-256 manifest in the repository.
