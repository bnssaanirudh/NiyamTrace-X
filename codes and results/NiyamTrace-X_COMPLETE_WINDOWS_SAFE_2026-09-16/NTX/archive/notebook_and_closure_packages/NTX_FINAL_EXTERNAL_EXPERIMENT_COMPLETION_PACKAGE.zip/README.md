Run QUICK first. When claims are supported, run STANDARD then FULL. Set NTX_SELFTEST=1 to verify parsers/exports without API spend. Final cell downloads processed, paper, raw, and master ZIPs.
