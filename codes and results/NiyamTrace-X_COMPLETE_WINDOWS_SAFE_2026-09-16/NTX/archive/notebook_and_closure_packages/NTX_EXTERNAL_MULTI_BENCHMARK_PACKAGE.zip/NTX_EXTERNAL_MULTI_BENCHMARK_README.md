# NTX External Multi-Benchmark Notebook

Notebook: `NTX_EXTERNAL_MULTI_BENCHMARK_TESTING.ipynb`

Validated structure:
- total cells: 26
- code cells: 17
- syntax errors: []

Recommended flow:
1. Run QUICK first.
2. Supply OpenRouter for AgentDojo/AgentDyn/tau3.
3. Supply any official BFCL provider keys you have.
4. Inspect run-status CSVs.
5. Only move to STANDARD/FULL after QUICK produces real numeric benchmark-native metrics.
6. MCP-SafetyBench is disabled by default because it can perform real external actions.
