# NiyamTrace-X — Four Parallel Q1 Experiment Notebooks

Pinned public repository commit: `c14661dbd11c42ebd1019b6a1a5c49b8643da137`.

Run the four notebooks independently in four separate Google Colab sessions.

1. **Semantic Anchor Stress** — multilingual corruption detection, confidence intervals, external/human CSV hook.
2. **SIL/IIEA Ablations** — 50k formal scenarios, baselines, exact paired tests, 20k safety-property checks.
3. **Verified Execution Broker** — replay, TOCTOU/stale-state, tampering, expiry, signatures, exact-delta and atomic rollback.
4. **Statistics & Reproducibility** — recomputed paper statistics, public 10k dataset leakage audit, power analysis, clustered bootstrap when exact raw artifacts are supplied.

## Scientific boundary
The public default branch does not contain the exact frozen per-case 2,000-case SIL/IIEA/Anchor
runtime and Qwen/GPT-OSS artifacts used by the manuscript. These notebooks add new evidence;
they do not fabricate those missing artifacts.

To support a defensible ~99% submission-readiness target, also publish those frozen artifacts
and add at least one genuinely independent human-authored or external benchmark.
