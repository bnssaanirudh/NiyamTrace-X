# NiyamTrace-X Local External Closure Implementation Plan

**Goal:** Run external benchmark validation without paid APIs by downloading open-weight models and evaluating them sequentially on one Colab GPU.

**Architecture:** One model is downloaded and served at a time through vLLM's local OpenAI-compatible server. Each model must pass local chat and automatic tool-call preflight before BFCL-v4, AgentDojo, and tau2/tau3 are executed. The model server is then terminated and GPU memory released before the next model starts.

**Default model families:** Granite, Qwen, Phi, Mistral/Ministral. Multiple Qwen sizes are included as additional stress points.

**Evidence constraints:**
- Native benchmark outputs only.
- Command exit code alone never counts as success.
- Failed/OOM/tool-incompatible models are logged and skipped.
- Model weights are not added to the results ZIP; model IDs, revisions, sizes, logs, and hashes/provenance are retained.
- Paper closure requires three distinct model families with supported evidence on BFCL-v4, AgentDojo, and tau3.
