# NiyamTrace-X External V2

This version directly fixes the uploaded run's root causes:
- AgentDojo invalid enum -> openai-compatible + model-id
- AgentDyn cached runs -> unique logdir + force-rerun
- tau2 missing websockets -> explicit install into tau2 .venv and import test
- BFCL module mismatch -> EvalScope BFCL-v4 OpenAI-compatible path
- MCP dependency pollution -> isolated environment and disabled-by-default run

Notebook cells: 19
Code cells: 13
Syntax errors: []
