# NiyamTrace-X Final ICLR/TACL Validation + Paper Finisher

## Run order
1. Open `NTX_Q1_14_ICLR_TACL_Final_Validation.ipynb`.
2. Start with `NTX_RUN_MODE=QUICK`.
3. Configure the OpenRouter key and any benchmark-specific credentials/templates requested by the notebook.
4. Resolve unsupported external adapters only when the official benchmark supports them.
5. Run `FULL` for the publication freeze.
6. Download `NTX_Q1_14_ICLR_TACL_FINAL_VALIDATION_RESULTS.zip`.
7. Open `NTX_Q1_15_Paper_Finisher_All_Formats.ipynb`.
8. Give it the final validation ZIP plus `NiyamTrace-X_All_Three_Formats_Source.zip`.
9. It compiles IEEE, Springer, and Elsevier PDFs and creates one final paper package.

## Built-in safeguards
- unsupported benchmarks remain unsupported;
- setup success is not treated as benchmark evidence;
- only `SUPPORTED` claims can be promoted to the manuscript;
- heterogeneous benchmark metrics are not averaged into one fake global score;
- frozen V2 evidence stays separate from post-freeze V3 hardening;
- final paper audit checks citations and references.

## Verification performed
- Notebook 14: 17 cells, 11 code cells, syntax errors = []
- Notebook 14 offline execution: PASS; internal claims supported, external claims correctly left MISSING.
- Notebook 15: 12 cells, 11 code cells, syntax errors = []
- Notebook 15 end-to-end synthetic execution: PASS.
- IEEE synthetic compile: PASS.
- Springer synthetic compile: PASS.
- Elsevier synthetic compile: PASS.
- Final citation/reference audit in synthetic execution: 0 unresolved citations / 0 unresolved references / 0 overfull hboxes.
