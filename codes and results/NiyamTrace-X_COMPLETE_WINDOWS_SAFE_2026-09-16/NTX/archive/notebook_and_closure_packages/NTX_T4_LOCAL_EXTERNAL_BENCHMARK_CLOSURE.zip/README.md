# NiyamTrace-X T4 Local External Closure

Use a fresh Google Colab NVIDIA T4 runtime.

Key changes:
- FP16 vLLM serving.
- 78% GPU-memory cap in CLOSURE mode.
- 4096-token context.
- Eager execution and max 2 sequences.
- Isolated Python 3.12 vLLM environment.
- One model per execution cell instead of one long Cell 7.
- Per-model and per-benchmark checkpoints.
- Core families: Granite, Qwen, Phi, Mistral.
- Supplemental models: xLAM-1B, xLAM-3B, Qwen2.5-7B-AWQ.
- Optional gated Llama-3.2-3B if HF_TOKEN is already set.

Recommended:
1. New Colab notebook.
2. Runtime > Change runtime type > T4 GPU.
3. Open this notebook.
4. Leave MODE=CLOSURE.
5. Run all.
6. If execution stops, rerun from the top; completed slices in the current runtime are reused.
7. Download NTX_T4_LOCAL_EXTERNAL_CLOSURE_RESULTS.zip.
