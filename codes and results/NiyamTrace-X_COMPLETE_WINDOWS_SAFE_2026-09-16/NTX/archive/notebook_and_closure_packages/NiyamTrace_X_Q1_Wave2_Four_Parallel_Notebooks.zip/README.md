# NiyamTrace-X Q1 Wave 2 — Four Parallel Colab Notebooks

Run these four notebooks independently/in parallel.

- **05 Frozen Runtime Ablation**: real 2,000-case 2x2 runtime ablation, Shapley attribution, clustered bootstrap.
- **06 Metamorphic Semantic Attack Lab**: frozen-vs-hardened Anchor Lock differential testing, Unicode/adversarial transformations, vendor/year regression.
- **07 Verified Execution Broker V2**: transaction-first capability execution, persistent nonces, concurrency/race regression, rollback and transactional outbox.
- **08 Risk-Calibrated Selective Authorization**: group-disjoint train/calibration/test risk control using deployment-observable features only.

Notebooks 05, 06 and 08 require `NiyamTrace-X_Frozen_Raw_Evidence_Recovered.zip`; it is included next to the notebooks in this bundle. In Colab, upload that ZIP when prompted. Notebook 07 is self-contained.

Every notebook ends with a cell that creates and downloads its own results ZIP.
