# NiyamTrace-X Wave 3 — External Generalization + Multi-Model Validation

Run 09–12 independently/in parallel. Run 13 only after downloading the four result ZIPs.

## Files
- 09: Anchor Lock V3 hardening + frozen non-regression. CPU only.
- 10: BFCL-v4 official EvalScope multi-model evaluation + MLCL availability gate. Requires configured model endpoints.
- 11: AgentDojo official clean/attack runs + Agent-SafetyBench repository/evaluator adapter. Requires configured model endpoints for AgentDojo.
- 12: tau3-era tau-bench stateful multi-model evaluation. Requires model endpoint(s), git/network, and benchmark dependencies.
- 13: Unified meta-analysis. No model calls.

## Multi-model configuration
Set environment variable `NTX_MODELS_JSON` to a JSON array using `MODEL_CONFIG_TEMPLATE.json` as the shape. API keys remain in environment variables / runtime state rather than being written into output manifests.

## Run modes
Set `NTX_RUN_MODE` to `QUICK`, `STANDARD`, or `FULL`. Start with QUICK. Formal paper runs should use FULL where resources permit.

## Evidence discipline
External benchmark adapters preserve the official benchmark score separately from NiyamTrace-X post-hoc effect proxies. Unsupported mappings remain unsupported; the notebooks never invent labels or silently replace official graders.

Every notebook ends with an automatic result-ZIP download cell.
