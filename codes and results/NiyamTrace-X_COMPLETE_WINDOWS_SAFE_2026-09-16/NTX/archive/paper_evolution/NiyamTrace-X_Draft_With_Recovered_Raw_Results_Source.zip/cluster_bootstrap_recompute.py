import json
from pathlib import Path
import numpy as np
import pandas as pd

SEED = 20260911
B = 50000
ROOT = Path(__file__).resolve().parent
RAW = ROOT / 'raw'

def load_jsonl(path):
    with open(path, encoding='utf-8') as f:
        return pd.DataFrame(json.loads(line) for line in f if line.strip())

q = load_jsonl(RAW / 'qwen_results.jsonl')
g = load_jsonl(RAW / 'gptoss_results.jsonl')
d = load_jsonl(RAW / 'holdout2000.jsonl')

assert len(q) == len(g) == len(d) == 2000
assert d['variant_group_id'].nunique() == 500
assert set(d.groupby('variant_group_id').size()) == {4}

q['raw_correct'] = q['raw_policy_verdict'].eq(q['expected_verdict'])
groups = sorted(d['variant_group_id'].unique())

def group_matrix(df, col):
    return np.array([
        df.loc[df['variant_group_id'].eq(gid), col].astype(float).to_numpy()
        for gid in groups
    ])

q_dec = group_matrix(q, 'decision_correct')
g_dec = group_matrix(g, 'decision_correct')
q_sem = group_matrix(q, 'semantic_correct')
g_sem = group_matrix(g, 'semantic_correct')
q_raw = group_matrix(q, 'raw_correct')

rng = np.random.default_rng(SEED)
parts = []
for start in range(0, B, 2000):
    n = min(2000, B-start)
    idx = rng.integers(0, len(groups), size=(n, len(groups)))
    qd = q_dec.mean(axis=1)[idx].mean(axis=1)
    gd = g_dec.mean(axis=1)[idx].mean(axis=1)
    qs = q_sem.mean(axis=1)[idx].mean(axis=1)
    gs = g_sem.mean(axis=1)[idx].mean(axis=1)
    qr = q_raw.mean(axis=1)[idx].mean(axis=1)
    parts.append(np.column_stack([qd, gd, qs, gs, qd-qr, qd-gd]))
boot = np.vstack(parts)

names = [
    'Qwen final decision accuracy',
    'GPT-OSS final decision accuracy',
    'Qwen semantic accuracy',
    'GPT-OSS semantic accuracy',
    'Qwen final-minus-raw decision accuracy',
    'Qwen-minus-GPT final decision accuracy',
]
points = [
    q['decision_correct'].mean(),
    g['decision_correct'].mean(),
    q['semantic_correct'].mean(),
    g['semantic_correct'].mean(),
    q['decision_correct'].mean() - q['raw_correct'].mean(),
    q['decision_correct'].mean() - g['decision_correct'].mean(),
]
rows=[]
for i, name in enumerate(names):
    lo, hi = np.quantile(boot[:, i], [0.025, 0.975])
    rows.append({'quantity':name,'point':points[i],'ci95_low':lo,'ci95_high':hi})

out = pd.DataFrame(rows)
out.to_csv(ROOT / 'cluster_bootstrap_summary_recomputed.csv', index=False)
print(out.to_string(index=False))
eligible_groups = d.loc[d['expected_verdict'].ne('ALLOW'), 'variant_group_id'].nunique()
print('eligible_nonallow_groups =', eligible_groups)
print('group_zero_event_upper95 =', 1 - 0.05**(1/eligible_groups))
