# Reference Verification

The final bibliography was restricted to archival/published scholarly papers. Model cards, repository entries, miscellaneous preprints, and unpublished 2026 authorization manuscripts were removed from the scholarly bibliography.

The final manuscript contains 13 bibliography entries and uses all 13. There are no unresolved citation keys and no uncited bibliography entries.

| Key | Publication status | Venue / archival source |
|---|---|---|
| react2023 | Published | ICLR 2023 / OpenReview |
| toolemu2024 | Published | ICLR 2024 / OpenReview |
| injecagent2024 | Published | Findings of ACL 2024, DOI 10.18653/v1/2024.findings-acl.624 |
| agentdojo2024 | Published | NeurIPS 2024 Datasets and Benchmarks, DOI 10.52202/079017-2636 |
| asb2025 | Published | ICLR 2025 proceedings |
| agentsafetybench2025 | Published | COLM 2025 / OpenReview |
| bfcl2025 | Published | ICML 2025, PMLR 267:48371-48392 |
| taubench2025 | Published | ICLR 2025 / OpenReview |
| lostexecution2026 | Published | ACL 2026, DOI 10.18653/v1/2026.acl-long.2039 |
| attriguard2026 | Published | USENIX Security 2026, pp. 1547-1566 |
| uncertaintyagent2024 | Published | Findings of ACL 2024, DOI 10.18653/v1/2024.findings-acl.398 |
| saltzer1975 | Published | Proceedings of the IEEE, DOI 10.1109/PROC.1975.9939 |
| schneider2000 | Published | ACM TISSEC, DOI 10.1145/353323.353382 |

The machine-readable publication audit is `audits/REFERENCE_PUBLICATION_AUDIT.csv`.
