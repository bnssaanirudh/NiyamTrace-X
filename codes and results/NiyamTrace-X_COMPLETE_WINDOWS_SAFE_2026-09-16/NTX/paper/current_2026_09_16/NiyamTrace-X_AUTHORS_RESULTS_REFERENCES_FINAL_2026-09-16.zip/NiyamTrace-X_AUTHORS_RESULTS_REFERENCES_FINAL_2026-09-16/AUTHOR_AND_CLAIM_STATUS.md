# NiyamTrace-X - Final Author and Claim Status

## Authors

1. **Badampudi Agasthya Anirudh**  
   School of Computer Science and Engineering, Vellore Institute of Technology, Vellore, Tamil Nadu, India  
   badampudi.agasthya2023@vitstudent.ac.in

2. **Sri Pranav K**  
   School of Computer Science and Engineering, Vellore Institute of Technology, Vellore, Tamil Nadu, India  
   sripranav.k2023@vitstudent.ac.in

3. **Vijayarajan V** - **Corresponding author**  
   Department of Quantum AI, School of Computer Science and Engineering, Vellore Institute of Technology, Vellore, Tamil Nadu, India  
   vijayarajan.v@vit.ac.in

No honorific such as “Dr.” is used in the manuscript author blocks.

## New external-result integration

The two supplied result archives were audited before manuscript integration.

- Granite-3.3-2B: chat/automatic-tool/forced-tool preflight passed. BFCL timed out without a retained official score. AgentDojo produced 9 valid cases across banking, workspace, and travel; Slack failed. The local stateful runner completed 6/6 trajectories with rewards 1,1,0,0,0,0 (mean 0.333).
- Qwen2.5-3B: tool preflight passed. BFCL timed out without a retained official score. AgentDojo produced 9 valid cases across banking, workspace, and travel; Slack failed. The local stateful runner completed 4/6 trajectories, all scored 0; both telecom tasks exceeded the configured context budget and were not scored.
- Hermes-3/Llama-3.1-8B-AWQ: no benchmark result is claimed. The standalone continuation stopped before inference because of a notebook-level `HF_TOKEN` initialization error.

### Scientific boundary

These external runners call the served model/tool interface directly and do **not** pass benchmark actions through the NiyamTrace-X semantic authorization layer. They are therefore reported as external benchmark-harness/model-tool evidence, not direct NiyamTrace-X system-safety validation.

The paper does **not** claim:
- BFCL performance from the timed-out runs;
- complete AgentDojo coverage;
- a successful third independent Llama-family benchmark result;
- three-family direct external generalization; or
- external system-level superiority.
