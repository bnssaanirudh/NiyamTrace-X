# Final QA Report

## IEEE
- Pages: 12
- Citation keys used / bibliography entries: 13 / 13
- Unresolved citations: 0
- Uncited bibliography entries: 0
- ArXiv/preprint bibliography entries: False
- Three authors present: True
- Corresponding-author marker present: True
- Anonymous Authors present: False
- “Dr.” title used for Vijayarajan V: False
- All three author emails present: True
- SCSE affiliation source verified: True
- Undefined references/citations in final log: False
- Overfull hboxes: 0
- **PASS: True**

## SPRINGER
- Pages: 23
- Citation keys used / bibliography entries: 13 / 13
- Unresolved citations: 0
- Uncited bibliography entries: 0
- ArXiv/preprint bibliography entries: False
- Three authors present: True
- Corresponding-author marker present: True
- Anonymous Authors present: False
- “Dr.” title used for Vijayarajan V: False
- All three author emails present: True
- SCSE affiliation source verified: True
- Undefined references/citations in final log: False
- Overfull hboxes: 0
- **PASS: True**

## ELSEVIER
- Pages: 12
- Citation keys used / bibliography entries: 13 / 13
- Unresolved citations: 0
- Uncited bibliography entries: 0
- ArXiv/preprint bibliography entries: False
- Three authors present: True
- Corresponding-author marker present: True
- Anonymous Authors present: False
- “Dr.” title used for Vijayarajan V: False
- All three author emails present: True
- SCSE affiliation source verified: True
- Undefined references/citations in final log: False
- Overfull hboxes: 0
- **PASS: True**

## Springer Supplement
- Pages: 2
- Author names present: True
- Anonymous Authors present: False
- Undefined refs: False
- Overfull hboxes: 0