# NiyamTrace-X - Authors, Results, References Final Package

This package contains the author-confirmed, result-integrated, publication-reference-audited versions of the NiyamTrace-X manuscript.

## Final papers

- `papers/NiyamTrace-X_IEEE_AUTHORS_RESULTS_FINAL.pdf`
- `papers/NiyamTrace-X_SPRINGER_AUTHORS_RESULTS_FINAL.pdf`
- `papers/NiyamTrace-X_SPRINGER_SUPPLEMENT_AUTHORS_RESULTS_FINAL.pdf`
- `papers/NiyamTrace-X_ELSEVIER_AUTHORS_RESULTS_FINAL.pdf`

## Source packages

- IEEE source ZIP
- Springer source ZIP, including supplement source
- Elsevier source ZIP

## Evidence and audits

- Both user-supplied final external-result archives
- Final external-results audit
- Reference-publication audit
- Final QA report
- SHA-256 manifest

## Important claim boundary

The final external model/tool experiments do not directly validate NiyamTrace-X because those external benchmark runners bypass the NiyamTrace-X authorization layer. The paper reports them as harness/model-tool evidence and keeps three-family direct external system generalization open.
