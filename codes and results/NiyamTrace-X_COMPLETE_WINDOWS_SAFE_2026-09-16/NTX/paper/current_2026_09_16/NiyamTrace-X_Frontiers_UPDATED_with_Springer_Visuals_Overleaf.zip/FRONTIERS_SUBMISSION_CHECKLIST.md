# Frontiers Submission Checklist — NiyamTrace-X

- [x] Original Research manuscript structure prepared.
- [x] Page/line-number review layout enabled.
- [x] 7 keywords supplied (Frontiers template permits 5–8).
- [x] Corresponding author identified: Vijayarajan V.
- [x] Data availability statement included after Conclusion.
- [x] Ethics statement included after Conclusion.
- [x] Author contributions included using CRediT-style roles.
- [x] Funding statement included.
- [x] Acknowledgments included.
- [x] Conflict of interest statement included.
- [x] Generative-AI use disclosed truthfully.
- [x] Figures provided as separate files.
- [x] Pseudocode replaces the former procedure table.
- [x] 21-reference published-only bibliography retained.
- [ ] All authors to confirm CRediT roles before submission.
- [ ] Authors/institution to confirm final APC-support wording.
- [ ] Choose Frontiers in Artificial Intelligence specialty section in submission portal.
