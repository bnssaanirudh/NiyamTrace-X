# NiyamTrace-X — Frontiers in Artificial Intelligence Overleaf Draft

## Main file
Open `main.tex` in Overleaf. It is a standalone Frontiers-style review draft with line numbers, author/affiliation/correspondence information, author-year citations, the Frontiers declaration order, external figure callouts, and the current manuscript content.

`frontiers_official.tex` is also included as a drop-in wrapper for Frontiers' official `FrontiersinHarvard` class. To use it, start from the official Frontiers LaTeX template in Overleaf (or download the template from Frontiers), copy `body_frontiers.tex`, `abstract.tex`, `references.bib`, and the `figures/` folder into that project, then use `frontiers_official.tex` as the main file. The official Frontiers example itself states that use of the Frontiers `.cls` is not mandatory for submission; Frontiers typesets the final accepted article.

## Changes made — deliberately limited
1. The old seven-row "Frozen v2 authorization procedure" table was replaced with Algorithm 1 pseudocode. Its logic is unchanged.
2. Inline TikZ architecture was exported as a separate external figure.
3. Repetitive near-1.0 bar charts were replaced by data-faithful visuals:
   - semantic-to-decision slope plot;
   - Anchor Lock v2→v3 discovered-miss trajectory;
   - VEB V2 outcome-count composition;
   - a small tau3 pilot line plot.
4. Frontiers-style declarations were placed after the Conclusion, as requested.
5. A truthful generative-AI disclosure was included. The manuscript cannot state that generative AI was not used because ChatGPT assisted with language editing, organization, LaTeX, and plotting/formatting code during manuscript preparation.

## Submission checks still requiring author confirmation
- Confirm the CRediT roles for all three authors before submission.
- Confirm VIT's final APC-support wording/policy for this submission.
- Confirm whether the public repository/commit should be retained in the submitted data-availability statement.
- Frontiers in Artificial Intelligence requires submission to a specialty section; select the final section in the submission portal.

## Figures
Every manuscript figure is provided separately as PDF, PNG, and 300-dpi JPEG. The PDF files are used by the Overleaf draft; the PNG/JPEG versions are available for the Frontiers upload workflow.
