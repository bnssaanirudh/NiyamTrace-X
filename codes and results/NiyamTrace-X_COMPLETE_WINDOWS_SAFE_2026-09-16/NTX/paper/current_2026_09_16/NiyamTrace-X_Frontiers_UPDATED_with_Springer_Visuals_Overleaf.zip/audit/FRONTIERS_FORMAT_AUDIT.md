# Frontiers format audit

- Target journal: **Frontiers in Artificial Intelligence**
- Draft article type: **Original Research**
- Review layout: one column, line numbers, author/affiliation/correspondence block, abstract, 7 keywords.
- Bibliography: 21 published papers; all 21 cited; no missing keys or uncited entries.
- Main text length: approximately 6,585 words including abstract and LaTeX-derived text, below the journal's 12,000-word Original Research ceiling.
- Figures: 5; tables: 8; combined = 13, below the Frontiers template note limiting Original Research to 15 combined figures/tables.
- Former procedure table: removed and replaced with pseudocode Algorithm 1.
- Figures are external callouts rather than TikZ/LaTeX drawings and are supplied individually as PDF, PNG, and 300-dpi JPEG.
- Data availability, ethics, author contributions, funding, acknowledgments, conflict of interest, and generative-AI statements appear after the Conclusion as requested.
- Final local compilation: 26 pages, 0 undefined citations/references, 0 overfull boxes.

## Important submission-time confirmations
The CRediT role allocation and the VIT APC-support wording should be confirmed by all authors/institution before submission. The standalone `main.tex` compiles on ordinary Overleaf. `frontiers_official.tex` is a drop-in wrapper for the official Frontiers Harvard class/template.
