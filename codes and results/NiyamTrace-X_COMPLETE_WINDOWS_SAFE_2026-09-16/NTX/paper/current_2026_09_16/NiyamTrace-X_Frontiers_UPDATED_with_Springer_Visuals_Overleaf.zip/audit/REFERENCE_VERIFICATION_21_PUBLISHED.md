# Reference Verification — 21 Published Papers

All 21 bibliography entries are published conference/workshop papers or journal articles. No arXiv-only preprints, model cards, software repositories, or unpublished manuscripts are used as literature references in these final versions.

| # | Key | Paper | Published venue | Type | DOI / archival record |
|---:|---|---|---|---|---|
| 1 | `react2023` | ReAct: Synergizing Reasoning and Acting in Language Models | ICLR 2023 | Conference paper | https://openreview.net/forum?id=WE_vluYUL-X |
| 2 | `toolemu2024` | Identifying the Risks of LM Agents with an LM-Emulated Sandbox | ICLR 2024 | Conference paper | https://openreview.net/forum?id=GEcwtMk1uA |
| 3 | `injecagent2024` | InjecAgent: Benchmarking Indirect Prompt Injections in Tool-Integrated Large Language Model Agents | Findings of ACL 2024 | Published conference paper | 10.18653/v1/2024.findings-acl.624 |
| 4 | `agentdojo2024` | AgentDojo: A Dynamic Environment to Evaluate Prompt Injection Attacks and Defenses for LLM Agents | NeurIPS 2024 Datasets and Benchmarks | Published conference paper | 10.52202/079017-2636 |
| 5 | `asb2025` | Agent Security Bench (ASB): Formalizing and Benchmarking Attacks and Defenses in LLM-based Agents | ICLR 2025 | Conference paper | https://proceedings.iclr.cc/ |
| 6 | `agentsafetybench2025` | Agent-SafetyBench: Evaluating the Safety of LLM Agents | COLM 2025 | Conference paper | https://openreview.net/forum?id=OeYdS51k8F |
| 7 | `bfcl2025` | The Berkeley Function Calling Leaderboard (BFCL): From Tool Use to Agentic Evaluation of Large Language Models | ICML 2025 / PMLR 267 | Published conference paper | https://proceedings.mlr.press/v267/patil25a.html |
| 8 | `taubench2025` | $\tau$-bench: A Benchmark for Tool-Agent-User Interaction in Real-World Domains | ICLR 2025 | Conference paper | https://openreview.net/forum?id=roNSXZpUDN |
| 9 | `lostexecution2026` | Lost in Execution: On the Multilingual Robustness of Tool Calling in Large Language Models | ACL 2026 | Published conference paper | 10.18653/v1/2026.acl-long.2039 |
| 10 | `attriguard2026` | AttriGuard: Defeating Indirect Prompt Injection in LLM Agents via Causal Attribution of Tool Invocations | USENIX Security 2026 | Published conference paper | https://www.usenix.org/conference/usenixsecurity26/presentation/he-yu |
| 11 | `uncertaintyagent2024` | Towards Uncertainty-Aware Language Agent | Findings of ACL 2024 | Published conference paper | 10.18653/v1/2024.findings-acl.398 |
| 12 | `saltzer1975` | The Protection of Information in Computer Systems | Proceedings of the IEEE, 1975 | Journal article | 10.1109/PROC.1975.9939 |
| 13 | `schneider2000` | Enforceable Security Policies | ACM TISSEC, 2000 | Journal article | 10.1145/353323.353382 |
| 14 | `toolformer2023` | Toolformer: Language Models Can Teach Themselves to Use Tools | NeurIPS 2023 | Published conference paper | 10.52202/075280-2997 |
| 15 | `apibank2023` | API-Bank: A Comprehensive Benchmark for Tool-Augmented LLMs | EMNLP 2023 | Published conference paper | 10.18653/v1/2023.emnlp-main.187 |
| 16 | `toolllm2024` | ToolLLM: Facilitating Large Language Models to Master 16000+ Real-World APIs | ICLR 2024 | Conference paper | https://proceedings.iclr.cc/paper_files/paper/2024/hash/28e50ee5b72e90b50e7196fde8ea260e-Abstract-Conference.html |
| 17 | `gorilla2024` | Gorilla: Large Language Model Connected with Massive APIs | NeurIPS 2024 | Published conference paper | 10.52202/079017-4020 |
| 18 | `greshake2023` | Not What You've Signed Up For: Compromising Real-World LLM-Integrated Applications with Indirect Prompt Injection | ACM AISec 2023 | Published workshop paper | 10.1145/3605764.3623985 |
| 19 | `lampson1973` | A Note on the Confinement Problem | Communications of the ACM, 1973 | Journal article | 10.1145/362375.362389 |
| 20 | `clarkwilson1987` | A Comparison of Commercial and Military Computer Security Policies | IEEE Symposium on Security and Privacy 1987 | Published conference paper | 10.1109/SP.1987.10001 |
| 21 | `ligatti2005` | Edit Automata: Enforcement Mechanisms for Run-Time Security Policies | International Journal of Information Security, 2005 | Journal article | 10.1007/s10207-004-0046-8 |

## Citation-use audit

- Bibliography entries: **21**
- Distinct cited keys in manuscript: **21**
- Uncited bibliography entries: **0**
- Missing citation keys: **0**
- `@misc` / arXiv-only bibliography entries: **0**

The new references were integrated into the Related Work discussion rather than appended as uncited padding.