# Final QA — NiyamTrace-X Frontiers in Artificial Intelligence draft

- **approx_word_count_body_plus_abstract**: 6585
- **pages**: 26
- **tables**: 8
- **figures**: 5
- **algorithms**: 1
- **combined_figures_tables**: 13
- **bibliography_entries**: 21
- **distinct_cited_keys**: 21
- **missing_citation_keys**: []
- **uncited_bibliography_entries**: []
- **procedure_table_removed**: True
- **pseudocode_algorithm_present**: True
- **false_no_ai_statement_present**: False
- **declarations_after_conclusion_in_requested_order**: True
- **separate_figure_assets**: True
- **final_compile_undefined_citations_or_refs**: False
- **final_compile_overfull_boxes**: False

## Declaration integrity

- The human-participant boilerplate supplied in the request was not reused because this study does not involve human participants. The ethics statement now reflects the actual study design.
- The unrelated Dytective acknowledgment was not inserted.
- The requested statement that generative AI was not used was not inserted because it would be inaccurate. The draft contains a transparent Frontiers-compliant disclosure instead.
- The CRediT-style author-contribution allocation is included as a draft and should be confirmed by all authors before submission.

## Visual integrity

- Figure 2 uses only the reported per-language semantic and decision accuracies.
- Figure 3 uses only the reported 10,248 attacks, 1,496 v2 misses, 0 v3 misses, and 2,000 clean controls.
- Figure 4 uses only the reported 1,320 broker scenarios (120 valid + 1,200 invalid/crash/tamper/etc.).
- Figure 5 uses only the six hosted tau3 pilot rewards reported in the manuscript.