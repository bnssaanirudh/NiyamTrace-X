# NiyamTrace-X — 21 Published References Final Package

This revision expands the literature base from 13 to **21 cited published papers**.

New literature added:
- Toolformer — NeurIPS 2023
- API-Bank — EMNLP 2023
- ToolLLM — ICLR 2024
- Gorilla — NeurIPS 2024
- Greshake et al. indirect prompt injection — ACM AISec 2023
- Lampson confinement — Communications of the ACM 1973
- Clark-Wilson integrity policy — IEEE S&P 1987
- Ligatti et al. edit automata — International Journal of Information Security 2005

Every bibliography entry is cited in the manuscript. No arXiv-only/preprint/model-card references are used in the final bibliography.
