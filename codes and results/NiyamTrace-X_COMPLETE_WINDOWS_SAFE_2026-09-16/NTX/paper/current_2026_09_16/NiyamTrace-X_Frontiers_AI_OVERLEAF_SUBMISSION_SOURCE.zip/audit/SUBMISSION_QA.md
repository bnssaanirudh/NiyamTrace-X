# Frontiers submission QA

- Abstract: 231 words (limit 350)
- Scope statement: 157 words (portal limit 200)
- Main manuscript body: approximately 6,130 words before references/end matter (limit 12,000)
- References: 21 bibliography entries; 21 cited; 0 missing; 0 uncited
- Figures: 6
- Tables: 8
- Combined figures/tables: 14 (limit 15)
- Separate figure files: RGB JPEG, 300 DPI
- Undefined citations/references: 0
- Overfull boxes: 0
- PDF pages: 25
- Page numbers: present
- Line numbers: present
- Required Original Research top-level structure: present
- Tables moved to manuscript end: yes
- Figure captions/figures moved to manuscript end: yes
