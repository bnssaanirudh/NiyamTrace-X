from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass

from .schema import CandidateContract
from .scoring import canon_amount, canon_currency, canon_scope, canon_vendor


MONTHS = {
    "january": 1, "jan": 1,
    "february": 2, "feb": 2,
    "march": 3, "mar": 3,
    "april": 4, "apr": 4,
    "may": 5,
    "june": 6, "jun": 6,
    "july": 7, "jul": 7,
    "august": 8, "aug": 8,
    "september": 9, "sep": 9, "sept": 9,
    "october": 10, "oct": 10,
    "november": 11, "nov": 11,
    "december": 12, "dec": 12,
}

NEGATION_PATTERNS = [
    r"\bdo\s+not\b",
    r"\bdon['’]?t\b",
    r"\bnot\b",
    r"\bnever\b",
    r"\bmat\b",
    r"\bnahi\b",
    r"\bnahin\b",
    r"\bcheyyakandi\b",
    r"\bcheyya?kandi\b",
    r"\bcheyyavaddu\b",
    r"\bcheyavaddu\b",
    r"\bvaddu\b",
    r"చేయకండి",
    r"చేయవద్దు",
    r"వద్దు",
]

BROAD_PATTERNS = [
    r"\ball\b",
    r"\bevery\b",
    r"\bsabhi\b",
    r"\bsab\b",
    r"\bsare\b",
    r"\banni\b",
    r"\bandarini\b",
    r"అన్ని",
    r"అన్నీ",
]

NARROW_PATTERNS = [
    r"\bonly\b",
    r"\bsirf\b",
    r"\bkeval\b",
    r"\bmaatrame\b",
    r"\bmatrame\b",
    r"మాత్రమే",
]

VENDOR_RE = re.compile(
    r"(?:\bvendor\b|వెండర్)\s*[-:#]?\s*(\d{2,})",
    re.IGNORECASE,
)
YEAR_RE = re.compile(r"\b(20\d{2})\b")
INVOICE_ID_RE = re.compile(r"\bINV[-_ ]?\d+\b", re.IGNORECASE)
MONEY_RE = re.compile(
    r"(?P<symbol>[₹$€£])\s*(?P<amount>\d[\d,]*(?:\.\d+)?)",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class SurfaceAnchors:
    negated: bool
    broad_scope: bool
    narrow_scope: bool
    vendor_ids: tuple[str, ...]
    years: tuple[int, ...]
    months: tuple[int, ...]
    invoice_ids: tuple[str, ...]
    amounts: tuple[str, ...]
    currencies: tuple[str, ...]


def _norm(text: str) -> str:
    return unicodedata.normalize("NFKC", text).casefold()


def _contains_any(text: str, patterns: list[str]) -> bool:
    return any(re.search(p, text, flags=re.IGNORECASE) for p in patterns)


def _money(text: str) -> tuple[tuple[str, ...], tuple[str, ...]]:
    amounts: list[str] = []
    currencies: list[str] = []
    symbol_to_currency = {"₹": "INR", "$": "USD", "€": "EUR", "£": "GBP"}

    for m in MONEY_RE.finditer(text):
        canon = canon_amount(m.group("amount"))
        if canon is not None:
            amounts.append(canon)
        currencies.append(symbol_to_currency[m.group("symbol")])

    return tuple(dict.fromkeys(amounts)), tuple(dict.fromkeys(currencies))


def extract_surface_anchors(text: str) -> SurfaceAnchors:
    norm = _norm(text)
    vendors = tuple(dict.fromkeys(VENDOR_RE.findall(norm)))
    years = tuple(dict.fromkeys(int(x) for x in YEAR_RE.findall(norm)))

    months_found: list[int] = []
    for name, month in MONTHS.items():
        if re.search(rf"\b{re.escape(name)}\b", norm):
            months_found.append(month)

    invoice_ids = tuple(
        dict.fromkeys(
            x.upper().replace("_", "-").replace(" ", "-")
            for x in INVOICE_ID_RE.findall(text)
        )
    )
    amounts, currencies = _money(text)

    return SurfaceAnchors(
        negated=_contains_any(norm, NEGATION_PATTERNS),
        broad_scope=_contains_any(norm, BROAD_PATTERNS),
        narrow_scope=_contains_any(norm, NARROW_PATTERNS),
        vendor_ids=vendors,
        years=years,
        months=tuple(dict.fromkeys(months_found)),
        invoice_ids=invoice_ids,
        amounts=amounts,
        currencies=currencies,
    )


def anchor_violations(text: str, candidate: CandidateContract) -> list[str]:
    """
    Fail closed when explicit protected surface anchors contradict the
    structured interpretation.

    The guard never repairs, broadens, or authorizes a candidate.
    """
    a = extract_surface_anchors(text)
    bad: set[str] = set()

    if a.negated and not candidate.negated:
        bad.add("negation")

    if a.vendor_ids:
        cv = canon_vendor(candidate.vendor_id)
        if cv not in set(a.vendor_ids):
            bad.add("vendor_id")

    if a.years and candidate.year not in set(a.years):
        bad.add("year")

    if a.months and candidate.month not in set(a.months):
        bad.add("month")

    scope = canon_scope(candidate.scope)

    if a.broad_scope and scope != "all":
        bad.add("quantifier_all")

    if a.narrow_scope and not a.broad_scope:
        if a.invoice_ids:
            raw_scope = (candidate.scope or "").upper().replace("_", "-").replace(" ", "-")
            if not all(i in raw_scope for i in a.invoice_ids):
                bad.add("quantifier_only")
        elif scope not in {"matching", "only matching"}:
            bad.add("quantifier_only")

    if a.amounts:
        ca = canon_amount(candidate.amount)
        if ca not in set(a.amounts):
            bad.add("amount")

    if a.currencies:
        cc = canon_currency(candidate.currency)
        if cc not in set(a.currencies):
            bad.add("currency")

    return sorted(bad)
