import aiohttp,json,time
from .prompting import messages

class LocalLLM:
    def __init__(self,base_url,model,timeout_s=120):
        self.base_url=base_url.rstrip("/"); self.model=model; self.timeout_s=timeout_s

    async def compile(self,session,text):
        payload={
            "model": self.model,
            "messages": messages(text),
            "temperature": 0,
            "max_tokens": 700,
            "chat_template_kwargs": {"enable_thinking": False},
        }
        t0=time.perf_counter()
        async with session.post(f"{self.base_url}/chat/completions",json=payload,
                                timeout=aiohttp.ClientTimeout(total=self.timeout_s)) as r:
            body=await r.text()
            if r.status!=200: raise RuntimeError(f"HTTP {r.status}: {body[:500]}")
            data=json.loads(body)
        return data,(time.perf_counter()-t0)*1000

def extract_content(api_response):
    return api_response["choices"][0]["message"]["content"]
