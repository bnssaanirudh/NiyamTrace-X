import json,re

def parse_json_object(text: str):
    text=text.strip()
    if text.startswith("```"):
        text=re.sub(r"^```(?:json)?\s*","",text)
        text=re.sub(r"\s*```$","",text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start=text.find("{"); end=text.rfind("}")
        if start>=0 and end>start:
            return json.loads(text[start:end+1])
        raise
