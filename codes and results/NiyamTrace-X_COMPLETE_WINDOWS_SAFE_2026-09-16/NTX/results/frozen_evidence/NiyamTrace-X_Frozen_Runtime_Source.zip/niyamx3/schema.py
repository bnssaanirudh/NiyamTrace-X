from __future__ import annotations

from pydantic import BaseModel, Field, field_validator
from typing import Literal

Relation = Literal[
    "EQUIVALENT",
    "NARROWER",
    "BROADER",
    "NEGATED",
    "ENTITY_SHIFT",
    "TEMPORAL_SHIFT",
    "VALUE_SHIFT",
    "AMBIGUOUS",
]


class CandidateContract(BaseModel):
    action: str
    vendor_id: str | None = None
    month: int | None = Field(default=None, ge=1, le=12)
    year: int | None = None
    amount: str | None = None
    currency: str | None = None
    scope: str | None = None
    negated: bool = False
    uncertainty: dict[str, list[str]] = Field(default_factory=dict)

    @field_validator("uncertainty", mode="before")
    @classmethod
    def normalize_uncertainty(cls, value):
        if value is None:
            return {}
        if not isinstance(value, dict):
            raise ValueError("uncertainty must be a JSON object")
        out: dict[str, list[str]] = {}
        for key, vals in value.items():
            if vals is None:
                items = []
            elif isinstance(vals, (list, tuple, set)):
                items = list(vals)
            else:
                items = [vals]
            out[str(key)] = [str(item) for item in items]
        return out


class InterpretationSet(BaseModel):
    candidates: list[CandidateContract] = Field(min_length=1, max_length=6)
    critical_disagreements: list[str] = Field(default_factory=list)
    needs_clarification: bool = False
    clarification_question: str | None = None


class BenchmarkCase(BaseModel):
    case_id: str
    variant_group_id: str
    raw_text: str
    language: str
    relation: Relation
    risk: Literal["LOW", "MEDIUM", "HIGH", "CRITICAL"]

    # What the sentence linguistically means.
    semantic_expected: CandidateContract
    expected_disagreements: list[str] = Field(default_factory=list)
    expected_needs_clarification: bool = False

    # What the authenticated/policy context permits.
    authorized_contract: CandidateContract
    allowed_targets: list[str]
    allowed_fields: list[str]

    expected_verdict: Literal["ALLOW", "BLOCK", "CLARIFY"]
    tags: list[str] = Field(default_factory=list)
