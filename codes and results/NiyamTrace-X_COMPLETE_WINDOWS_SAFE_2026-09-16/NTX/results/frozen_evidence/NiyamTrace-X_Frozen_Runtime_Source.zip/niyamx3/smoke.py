import argparse,asyncio,aiohttp,json
from .client import LocalLLM,extract_content
from .jsonutil import parse_json_object
from .schema import InterpretationSet

CASES=[
 "Archive March 2026 invoices for vendor 1042.",
 "Archive March invoices for vendor 1042.",
 "Do not archive March 2026 invoices for vendor 1042.",
 "Archive only invoice INV-100 for vendor 1042.",
 "Vendor 1042 ke March 2026 ke matching invoices archive karo.",
 "Vendor 1042 ki March 2026 matching invoices archive cheyyandi.",
 "వెండర్ 1042 కు March 2026 matching ఇన్వాయిసులను ఆర్కైవ్ చేయండి.",
]

async def go(a):
    llm=LocalLLM(a.base_url,a.model,180)
    async with aiohttp.ClientSession() as s:
        for t in CASES:
            api,ms=await llm.compile(s,t); content=extract_content(api)
            parsed=InterpretationSet.model_validate(parse_json_object(content))
            print(json.dumps({"text":t,"ms":round(ms,1),"parsed":parsed.model_dump()},ensure_ascii=False))
    print("SMOKE PASS")

def main():
    p=argparse.ArgumentParser(); p.add_argument("--base-url",default="http://127.0.0.1:8000/v1"); p.add_argument("--model",required=True)
    asyncio.run(go(p.parse_args()))
if __name__=="__main__": main()
