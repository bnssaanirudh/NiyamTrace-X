import argparse,json,sqlite3,uuid
from pathlib import Path

def toctou():
    c=sqlite3.connect(":memory:"); c.execute("create table x(id integer primary key,value integer,version integer)")
    c.execute("insert into x values(1,10,1)"); c.commit(); snap=c.execute("select value,version from x where id=1").fetchone()
    c.execute("update x set value=11,version=2 where id=1"); c.commit()
    cur=c.execute("update x set value=20,version=version+1 where id=1 and version=?",(snap[1],)); c.commit()
    return {"name":"toctou_version_guard","passed":cur.rowcount==0}

def atomicity():
    c=sqlite3.connect(":memory:"); c.execute("create table x(id integer primary key,value integer)")
    c.executemany("insert into x values(?,?)",[(1,10),(2,20)]); c.commit()
    try:
        c.execute("begin"); c.execute("update x set value=99 where id=1"); raise RuntimeError("injected")
    except RuntimeError: c.rollback()
    return {"name":"atomic_rollback","passed":c.execute("select id,value from x order by id").fetchall()==[(1,10),(2,20)]}

def idem():
    seen=set(); effects=0
    for _ in range(100):
        if "abc" not in seen: seen.add("abc"); effects+=1
    return {"name":"idempotency","passed":effects==1,"effect_count":effects}

def replay():
    seen=set(); n=uuid.uuid4().hex; first=n not in seen; seen.add(n); second=n not in seen
    return {"name":"replay_rejection","passed":first and not second}

def main():
    p=argparse.ArgumentParser(); p.add_argument("--out",required=True); a=p.parse_args()
    rows=[toctou(),atomicity(),idem(),replay()]; out=Path(a.out); out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(rows,indent=2),encoding="utf-8"); print(json.dumps(rows,indent=2))
    if not all(r["passed"] for r in rows): raise SystemExit(1)
if __name__=="__main__": main()
