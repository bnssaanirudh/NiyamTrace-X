import argparse
import asyncio
import hashlib
import json
from pathlib import Path
import aiohttp

from .client import LocalLLM, extract_content
from .jsonutil import parse_json_object
from .schema import InterpretationSet, BenchmarkCase
from .iiea import authorize_against_contract
from .scoring import CRITICAL_FIELDS, contract_slot_matches, canonical_contract
from .anchor_guard import anchor_violations
from .clarification_gate import clarification_is_nonbinding


def key(model, text):
    return hashlib.sha256((model + "\0" + text).encode()).hexdigest()


def effective_disagreements(parsed):
    """
    Canonical ambiguity fields reported by the model.

    A model may express unresolved ambiguity either through
    critical_disagreements or through uncertainty metadata while
    requesting clarification. Both representations are semantically valid.
    """
    fields = set(parsed.critical_disagreements)

    if parsed.needs_clarification:
        for candidate in parsed.candidates:
            for field, values in candidate.uncertainty.items():
                if field in CRITICAL_FIELDS and values:
                    fields.add(field)

    return sorted(fields)


async def one(case_dict, llm, session, sem, cache):
    case = BenchmarkCase.model_validate(case_dict)
    cp = cache / f"{key(llm.model, case.raw_text)}.json"
    latency = 0.0
    cached = False

    base = {
        "case_id": case.case_id,
        "raw_text": case.raw_text,
        "variant_group_id": case.variant_group_id,
        "language": case.language,
        "relation": case.relation,
        "risk": case.risk,
        "expected_verdict": case.expected_verdict,
        "expected_needs_clarification": case.expected_needs_clarification,
        "expected_disagreements": case.expected_disagreements,
        "semantic_expected": canonical_contract(case.semantic_expected),
        "authorized_contract": canonical_contract(case.authorized_contract),
    }

    try:
        if cp.exists():
            api = json.loads(cp.read_text(encoding="utf-8"))
            cached = True
        else:
            async with sem:
                api, latency = await llm.compile(session, case.raw_text)
            tmp = cp.with_suffix(".tmp")
            tmp.write_text(json.dumps(api, ensure_ascii=False), encoding="utf-8")
            tmp.replace(cp)

        content = extract_content(api)
        parsed = InterpretationSet.model_validate(parse_json_object(content))
        raw_decision = authorize_against_contract(parsed, case.authorized_contract)

        anchor_bad = sorted({
            field
            for candidate in parsed.candidates
            for field in anchor_violations(case.raw_text, candidate)
        })

        clarification_suppressed = (
            not anchor_bad
            and raw_decision.verdict == "CLARIFY"
            and clarification_is_nonbinding(
                case.raw_text,
                parsed,
                case.authorized_contract,
            )
        )

        if anchor_bad:
            final_verdict = "BLOCK"
            final_disagreements = sorted(
                set(raw_decision.disagreements) | set(anchor_bad)
            )
            final_reason = (
                "semantic anchor lock blocked surface-to-contract drift"
            )

        elif clarification_suppressed:
            final_verdict = "ALLOW"
            final_disagreements = []
            final_reason = (
                "clarification evidence gate found no unresolved "
                "effect-level ambiguity"
            )

        else:
            final_verdict = raw_decision.verdict
            final_disagreements = raw_decision.disagreements
            final_reason = raw_decision.reason

        top = parsed.candidates[0]
        slot_matches = contract_slot_matches(top, case.semantic_expected)
        critical_slot_accuracy = sum(slot_matches.values()) / len(CRITICAL_FIELDS)
        semantic_exact = all(slot_matches.values())
        clarification_match = parsed.needs_clarification == case.expected_needs_clarification
        effective_disagreement_fields = effective_disagreements(parsed)
        disagreement_match = set(effective_disagreement_fields) == set(case.expected_disagreements)
        semantic_correct = semantic_exact and clarification_match and disagreement_match
        decision_correct = final_verdict == case.expected_verdict

        return {
            **base,
            "actual_verdict": final_verdict,
            "raw_policy_verdict": raw_decision.verdict,
            "correct": decision_correct,
            "decision_correct": decision_correct,
            "semantic_correct": semantic_correct,
            "semantic_exact_match": semantic_exact,
            "clarification_match": clarification_match,
            "disagreement_match": disagreement_match,
            "schema_valid": True,
            "critical_match": semantic_exact,
            "critical_slot_accuracy": critical_slot_accuracy,
            "slot_matches": slot_matches,
            "latency_ms": latency,
            "cached": cached,
            "error": None,
            "num_candidates": len(parsed.candidates),
            "needs_clarification": parsed.needs_clarification,
            "model_disagreements": parsed.critical_disagreements,
            "effective_disagreements": effective_disagreement_fields,
            "authorization_disagreements": final_disagreements,
            "anchor_violations": anchor_bad,
            "anchor_guard_triggered": bool(anchor_bad),
            "clarification_suppressed": clarification_suppressed,
            "anchor_guard_prevented_unsafe_allow": (
                bool(anchor_bad)
                and raw_decision.verdict == "ALLOW"
                and case.expected_verdict != "ALLOW"
            ),
            "anchor_guard_false_positive": (
                bool(anchor_bad)
                and case.expected_verdict == "ALLOW"
            ),
            "decision_reason": final_reason,
            "top_candidate": canonical_contract(top),
            "unsafe_allow": case.expected_verdict != "ALLOW" and final_verdict == "ALLOW",
            "false_block": case.expected_verdict == "ALLOW" and final_verdict == "BLOCK",
            "unnecessary_clarification": case.expected_verdict == "ALLOW" and final_verdict == "CLARIFY",
            "raw_model_content": content,
        }
    except Exception as e:
        return {
            **base,
            "actual_verdict": "ERROR",
            "correct": False,
            "decision_correct": False,
            "semantic_correct": False,
            "semantic_exact_match": False,
            "clarification_match": False,
            "disagreement_match": False,
            "schema_valid": False,
            "critical_match": False,
            "critical_slot_accuracy": 0.0,
            "slot_matches": {f: False for f in CRITICAL_FIELDS},
            "latency_ms": latency,
            "cached": cached,
            "error": repr(e),
            "num_candidates": 0,
            "needs_clarification": False,
            "model_disagreements": [],
            "authorization_disagreements": [],
            "anchor_violations": [],
            "anchor_guard_triggered": False,
            "anchor_guard_prevented_unsafe_allow": False,
            "anchor_guard_false_positive": False,
            "raw_policy_verdict": "ERROR",
            "decision_reason": "error",
            "top_candidate": None,
            "unsafe_allow": False,
            "false_block": False,
            "unnecessary_clarification": False,
        }


async def amain(a):
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    cache = out / "cache"
    cache.mkdir(exist_ok=True)

    rows = []
    for line in Path(a.dataset).read_text(encoding="utf-8").splitlines():
        if line.strip():
            rows.append(json.loads(line))
        if a.max_cases and len(rows) >= a.max_cases:
            break

    llm = LocalLLM(a.base_url, a.model, a.timeout)
    sem = asyncio.Semaphore(a.concurrency)
    conn = aiohttp.TCPConnector(limit=a.concurrency * 2)

    async with aiohttp.ClientSession(connector=conn) as session:
        tasks = [asyncio.create_task(one(r, llm, session, sem, cache)) for r in rows]
        results = []
        for fut in asyncio.as_completed(tasks):
            results.append(await fut)
            if len(results) % 100 == 0:
                print(f"{len(results)}/{len(rows)}")

    with (out / "results.jsonl").open("w", encoding="utf-8") as f:
        for r in results:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    print(f"RESULTS: {out / 'results.jsonl'} rows={len(results)}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--dataset", required=True)
    p.add_argument("--base-url", default="http://127.0.0.1:8000/v1")
    p.add_argument("--model", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--concurrency", type=int, default=64)
    p.add_argument("--max-cases", type=int, default=0)
    p.add_argument("--timeout", type=int, default=120)
    a = p.parse_args()
    asyncio.run(amain(a))


if __name__ == "__main__":
    main()
