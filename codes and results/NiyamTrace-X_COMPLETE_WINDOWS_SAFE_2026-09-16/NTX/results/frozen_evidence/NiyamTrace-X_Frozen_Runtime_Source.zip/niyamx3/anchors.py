import re
from dataclasses import dataclass

PATTERNS = {
    "id": re.compile(r"\b(?:INV|VEN|VENDOR|USR|REQ|TKT)[-_ ]?\d+\b", re.I),
    "money": re.compile(r"(?:₹|\$|€|£)\s*\d[\d,]*(?:\.\d+)?|\b\d+(?:\.\d+)?\s*(?:lakh|lac|crore|k)\b", re.I),
    "date": re.compile(r"\b\d{1,4}[-/]\d{1,2}[-/]\d{1,4}\b"),
    "negation": re.compile(r"\b(?:not|don't|do not|never|except|mat|nahi|cheyyaku)\b", re.I),
    "quantifier": re.compile(r"\b(?:all|only|exactly|at most|at least|none|every|some|except)\b", re.I),
}

@dataclass(frozen=True)
class Anchor:
    kind: str
    value: str

def extract_anchors(text: str) -> set[Anchor]:
    out=set()
    for kind,rx in PATTERNS.items():
        for m in rx.finditer(text):
            out.add(Anchor(kind,m.group(0).strip().lower()))
    return out

def anchor_diff(a: str,b: str):
    aa,bb=extract_anchors(a),extract_anchors(b)
    return {"removed":aa-bb,"added":bb-aa}

def preserves_critical_anchors(a: str,b: str) -> bool:
    d=anchor_diff(a,b); critical={"id","money","date","negation","quantifier"}
    return not any(x.kind in critical for x in d["removed"]|d["added"])
