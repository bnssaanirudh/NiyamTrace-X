from __future__ import annotations

from .anchor_guard import extract_surface_anchors
from .schema import CandidateContract
from .scoring import (
    canon_action,
    canon_amount,
    canon_currency,
    canon_scope,
    canon_vendor,
)


def _same_effect(candidate: CandidateContract,
                 authorized: CandidateContract) -> bool:
    if canon_action(candidate.action) != canon_action(authorized.action):
        return False

    if canon_vendor(candidate.vendor_id) != canon_vendor(authorized.vendor_id):
        return False

    if candidate.month != authorized.month:
        return False

    if candidate.year != authorized.year:
        return False

    if canon_amount(candidate.amount) != canon_amount(authorized.amount):
        return False

    if canon_currency(candidate.currency) != canon_currency(authorized.currency):
        return False

    cs = canon_scope(candidate.scope)
    aus = canon_scope(authorized.scope)

    # Effect-equivalent representations for this benchmark contract.
    if {cs, aus} <= {"matching", "only matching"}:
        pass
    elif cs != aus:
        return False

    if bool(candidate.negated) != bool(authorized.negated):
        return False

    return True


def clarification_is_nonbinding(
    raw_text: str,
    parsed,
    authorized: CandidateContract,
) -> bool:
    """
    Return True only when a model requested clarification but all represented
    effect programs collapse to the same authenticated effect and explicit
    surface anchors support the relevant critical values.

    This gate cannot repair a mismatch or authorize a broader effect.
    """

    if not parsed.needs_clarification:
        return False

    if not parsed.candidates:
        return False

    # An explicit model-reported critical disagreement remains binding.
    if parsed.critical_disagreements:
        return False

    anchors = extract_surface_anchors(raw_text)

    # Every represented interpretation must already equal the authorized
    # effect. One safe candidate is not enough if another differs.
    for c in parsed.candidates:
        if not _same_effect(c, authorized):
            return False

    # Require explicit grounding for the identity/time/scope fields used
    # by the currently authorized effect.
    if authorized.vendor_id is not None:
        if canon_vendor(authorized.vendor_id) not in set(anchors.vendor_ids):
            return False

    if authorized.year is not None:
        if authorized.year not in set(anchors.years):
            return False

    if authorized.month is not None:
        if authorized.month not in set(anchors.months):
            return False

    scope = canon_scope(authorized.scope)

    if scope in {"matching", "only matching"}:
        # The instruction itself must explicitly constrain the scope.
        text = raw_text.casefold()

        explicit_matching = (
            "matching" in text
            or anchors.narrow_scope
        )

        if not explicit_matching:
            return False

    # Evaluate candidate uncertainty. A field is non-binding only when its
    # value is already fixed by surface evidence or has no effect value in
    # either candidate or authorization.
    for c in parsed.candidates:
        for field, values in c.uncertainty.items():
            if not values:
                continue

            if field == "vendor_id":
                if (
                    canon_vendor(c.vendor_id)
                    == canon_vendor(authorized.vendor_id)
                    and canon_vendor(c.vendor_id) in set(anchors.vendor_ids)
                ):
                    continue
                return False

            if field == "month":
                if c.month == authorized.month and c.month in set(anchors.months):
                    continue
                return False

            if field == "year":
                if c.year == authorized.year and c.year in set(anchors.years):
                    continue
                return False

            if field == "amount":
                if c.amount is None and authorized.amount is None:
                    continue

                ca = canon_amount(c.amount)
                if ca is not None and ca in set(anchors.amounts):
                    continue

                return False

            if field == "currency":
                if c.currency is None and authorized.currency is None:
                    continue

                cc = canon_currency(c.currency)
                if cc is not None and cc in set(anchors.currencies):
                    continue

                return False

            if field == "scope":
                if scope in {"matching", "only matching"} and (
                    anchors.narrow_scope or "matching" in raw_text.casefold()
                ):
                    continue
                return False

            if field == "negated":
                if bool(c.negated) == bool(authorized.negated):
                    if c.negated and anchors.negated:
                        continue
                    if not c.negated and not anchors.negated:
                        continue
                return False

            # Unknown critical uncertainty remains binding.
            return False

    return True
