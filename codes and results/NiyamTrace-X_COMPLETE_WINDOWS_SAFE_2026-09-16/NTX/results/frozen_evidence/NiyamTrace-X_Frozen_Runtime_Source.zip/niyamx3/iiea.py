from dataclasses import dataclass
from .schema import CandidateContract, InterpretationSet
from .scoring import (
    canon_action, canon_vendor, canon_amount, canon_currency, canon_scope,
)

CRITICAL = ("action", "vendor_id", "month", "year", "amount", "currency", "scope", "negated")


@dataclass
class IntersectionDecision:
    verdict: str
    disagreements: list[str]
    safe_contract: CandidateContract | None
    reason: str


def intersection_authorize(candidates):
    if not candidates:
        return IntersectionDecision("BLOCK", [], None, "no interpretations")
    if len(candidates) == 1:
        c = candidates[0]
        if c.negated:
            return IntersectionDecision("BLOCK", ["negated"], None, "explicitly negated")
        if c.year is None and c.action == "invoice.archive":
            return IntersectionDecision("CLARIFY", ["year"], None, "year unresolved")
        return IntersectionDecision("ALLOW", [], c, "single unambiguous interpretation")

    disagreements = []
    for field in CRITICAL:
        values = {str(getattr(c, field)) for c in candidates}
        if len(values) > 1:
            disagreements.append(field)
    if disagreements:
        return IntersectionDecision("CLARIFY", disagreements, None, "critical interpretations disagree")
    if any(c.negated for c in candidates):
        return IntersectionDecision("BLOCK", ["negated"], None, "negated")
    return IntersectionDecision("ALLOW", [], candidates[0], "all critical semantics agree")


def _scope_within(candidate_scope: str | None, authorized_scope: str | None) -> bool:
    c = canon_scope(candidate_scope)
    a = canon_scope(authorized_scope)
    if a is None:
        return c is None
    if c is None:
        return False
    if a == "all":
        return c in {"all", "matching", "only matching"}
    if a == "matching":
        return c in {"matching", "only matching"}
    if a == "only matching":
        return c == "only matching"
    return c == a


def _definite_authorization_violations(
    candidate: CandidateContract,
    authorized: CandidateContract,
) -> list[str]:
    """
    Detect explicit known values that exceed the authenticated
    authorization contract.

    Missing/unresolved values are NOT treated as violations here because
    they belong to the clarification path. Explicit shifted values are
    violations even when the model also requests clarification.
    """
    bad: list[str] = []

    if candidate.action and candidate.action != "unknown":
        if canon_action(candidate.action) != canon_action(authorized.action):
            bad.append("action")

    if candidate.vendor_id is not None:
        if canon_vendor(candidate.vendor_id) != canon_vendor(authorized.vendor_id):
            bad.append("vendor_id")

    if candidate.month is not None and candidate.month != authorized.month:
        bad.append("month")

    if candidate.year is not None and candidate.year != authorized.year:
        bad.append("year")

    if candidate.amount is not None:
        if canon_amount(candidate.amount) != canon_amount(authorized.amount):
            bad.append("amount")

    if candidate.currency is not None:
        if canon_currency(candidate.currency) != canon_currency(authorized.currency):
            bad.append("currency")

    if candidate.scope is not None:
        if not _scope_within(candidate.scope, authorized.scope):
            bad.append("scope")

    return bad


def _authorization_violations(candidate: CandidateContract, authorized: CandidateContract) -> list[str]:
    bad: list[str] = []
    if canon_action(candidate.action) != canon_action(authorized.action):
        bad.append("action")
    if canon_vendor(candidate.vendor_id) != canon_vendor(authorized.vendor_id):
        bad.append("vendor_id")
    if candidate.month != authorized.month:
        bad.append("month")
    if candidate.year != authorized.year:
        bad.append("year")
    if canon_amount(candidate.amount) != canon_amount(authorized.amount):
        bad.append("amount")
    if canon_currency(candidate.currency) != canon_currency(authorized.currency):
        bad.append("currency")
    if not _scope_within(candidate.scope, authorized.scope):
        bad.append("scope")
    if candidate.negated:
        bad.append("negated")
    return bad


def authorize_against_contract(parsed: InterpretationSet, authorized: CandidateContract) -> IntersectionDecision:
    if not parsed.candidates:
        return IntersectionDecision("BLOCK", [], None, "no interpretations")

    # Explicit negation is a denial, even if the model also reports uncertainty.
    if any(c.negated for c in parsed.candidates):
        return IntersectionDecision("BLOCK", ["negated"], None, "explicitly negated")

    # Explicit known values outside the authenticated contract take
    # precedence over clarification. Clarification may refine intent, but
    # must never elevate authorization.
    definite_violations: set[str] = set()
    for c in parsed.candidates:
        definite_violations.update(
            _definite_authorization_violations(c, authorized)
        )

    if definite_violations:
        return IntersectionDecision(
            "BLOCK",
            sorted(definite_violations),
            None,
            "explicit interpreted effect exceeds authenticated authorization contract",
        )

    # Unresolved semantics with no definite authorization violation require
    # clarification and must never auto-commit.
    if parsed.needs_clarification or parsed.critical_disagreements:
        fields = sorted(set(parsed.critical_disagreements))
        return IntersectionDecision(
            "CLARIFY",
            fields,
            None,
            "model reports unresolved ambiguity",
        )

    semantic = intersection_authorize(parsed.candidates)
    if semantic.verdict != "ALLOW":
        return semantic

    violations: set[str] = set()
    for c in parsed.candidates:
        violations.update(_authorization_violations(c, authorized))

    if violations:
        return IntersectionDecision(
            "BLOCK", sorted(violations), None,
            "interpreted effect exceeds authenticated authorization contract",
        )

    return IntersectionDecision("ALLOW", [], semantic.safe_contract, "safe under all interpretations and authorization")
