from pydantic import BaseModel
from typing import Literal
import hashlib,json

class EffectIR(BaseModel):
    effect_class: Literal["state_mutation","financial_transfer","external_communication","access_change"]
    resource_type: str
    resource_id: str
    attribute: str | None = None
    before: str | None = None
    after: str | None = None
    amount: str | None = None
    currency: str | None = None
    recipient: str | None = None
    reversibility: Literal["REVERSIBLE","COMPENSATABLE","IRREVERSIBLE"]="REVERSIBLE"

    def canonical(self):
        return json.dumps(self.model_dump(),sort_keys=True,separators=(",",":"))

    def fingerprint(self):
        return hashlib.sha256(self.canonical().encode()).hexdigest()

def archive_effect(invoice_id: str):
    return EffectIR(effect_class="state_mutation",resource_type="invoice",resource_id=invoice_id,
                    attribute="status",before="OPEN",after="ARCHIVED",reversibility="REVERSIBLE")
