from __future__ import annotations

from decimal import Decimal, InvalidOperation
import re
from .schema import CandidateContract

CRITICAL_FIELDS = (
    "action", "vendor_id", "month", "year",
    "amount", "currency", "scope", "negated",
)


def _norm_text(value: str | None) -> str | None:
    if value is None:
        return None
    return " ".join(str(value).strip().lower().split())


def canon_action(value: str | None) -> str | None:
    return _norm_text(value)


def canon_vendor(value: str | None) -> str | None:
    if value is None:
        return None
    return str(value).strip()


def canon_amount(value: str | None) -> str | None:
    if value is None:
        return None
    s = str(value).strip()
    s = s.replace(",", "").replace("₹", "")
    s = re.sub(r"\b(?:inr|rs\.?|rupees?)\b", "", s, flags=re.I).strip()
    try:
        d = Decimal(s)
    except (InvalidOperation, ValueError):
        return _norm_text(value)
    if d == d.to_integral():
        return str(d.quantize(Decimal("1")))
    return format(d.normalize(), "f")


def canon_currency(value: str | None) -> str | None:
    if value is None:
        return None
    s = _norm_text(value)
    if s in {"₹", "inr", "rs", "rs.", "rupee", "rupees", "indian rupee", "indian rupees"}:
        return "INR"
    if s in {"$", "usd", "us dollar", "us dollars"}:
        return "USD"
    return str(value).strip().upper()


def canon_scope(value: str | None) -> str | None:
    if value is None:
        return None
    s = _norm_text(value) or ""

    # Narrowing markers across the benchmark's four language views.
    narrow = any(x in s for x in ("only", "sirf", "maatrame", "matrame", "మాత్రమే"))
    broad = any(x in s for x in ("all", "sabhi", "anni", "అన్ని"))
    matching = "matching" in s

    if matching and narrow:
        return "only matching"
    if broad:
        return "all"
    if matching:
        return "matching"
    return s


def canonical_field(field: str, value):
    if field == "action":
        return canon_action(value)
    if field == "vendor_id":
        return canon_vendor(value)
    if field == "amount":
        return canon_amount(value)
    if field == "currency":
        return canon_currency(value)
    if field == "scope":
        return canon_scope(value)
    if field in {"month", "year"}:
        return None if value is None else int(value)
    if field == "negated":
        return bool(value)
    return value


def contract_slot_matches(pred: CandidateContract, exp: CandidateContract) -> dict[str, bool]:
    return {
        field: canonical_field(field, getattr(pred, field)) == canonical_field(field, getattr(exp, field))
        for field in CRITICAL_FIELDS
    }


def contract_exact_match(pred: CandidateContract, exp: CandidateContract) -> bool:
    return all(contract_slot_matches(pred, exp).values())


def canonical_contract(c: CandidateContract) -> dict:
    return {field: canonical_field(field, getattr(c, field)) for field in CRITICAL_FIELDS}
