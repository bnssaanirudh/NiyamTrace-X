# Editorial and analytical changes

The redraft retains the study's authorization construction and key experimental findings while removing repeated development chronology and claims unsupported by the evaluated path. No source experiment was rerun or rescored to hide a failure.

The primary paper now separates three boundaries: frozen reference verdicts, paired reference SQLite effects, and actual local inference followed by native broker execution. The tested native response schema has no explicit negation slot, and the separate model decision does not veto the proposal evaluated by the pipeline. Policy evidence retrieval and certificate enforcement cannot recover a prohibition absent from that proposal. This implementation detail explains why passing execution tests coexist with unsafe negation commits.

The empty-candidate authorization case is explicitly empty. The containment argument is conditional on semantic coverage, sound effect compilation, current policy, and complete mediation. It is not an unconditional theorem about model behavior.

Two statistical corrections matter: GPT-OSS clarification-only retains two unsafe verdicts, not six; and case-weighted clustered bootstrap intervals cannot be substituted with intervals for equal-weighted groups. A case-level McNemar value is kept only as an audit calculation because related requests are clustered. Zero observed events on generated groups is not reported as a deployed-population risk guarantee.

Strict semantic correctness, eight-field agreement, verdict correctness, nonempty authorized completion, unsafe business changes, and capability-ledger insertions remain distinct. Failed extractions stay in denominators. Cache reuse is disclosed.

The 32-request previously examined participant cohort is excluded from manuscript analyses because it does not provide fresh independent validation and the supplied ethics/consent record is incomplete. Its negative aggregate findings are retained in `Data/Native_Original_Private_Run_Aggregates.json`, without private request text. The public-language result used in the paper is the selected-class within-language diagnostic with retained raw outputs; older headline scores from a different protocol remain secondary archival entries.

All thirty reference records have a verification source and date. Titles, authors, venue/year and available identifiers were checked; source claims are used for their supported framework/dataset role rather than an invented cross-system performance comparison. Unestablished Agent-SafetyBench COLM publication metadata was replaced by its verified 2024 preprint record. Reference keys sometimes retain their historical year suffix; printed bibliographic years are authoritative.

The supplied author list, affiliation, contribution statements and no-competing-interest declaration were retained. Final author confirmation and funding details are listed separately rather than fabricated in the manuscripts.

## Complete-history revision

Recovered early stages 01–13, original October 6 baseline/red-team/stateful records, October 8 semantic/mutation/NLU/uncertainty records, additional October 11 contrasts and uncertainty, original native source controls, and local broker-repair evidence. Both Articles now restore the major historical findings and refer to a comprehensive supplementary document. The 46-entry inclusion map covers nested/duplicate exports and failed/planned attempts as well as completed studies. No denominator is enlarged by summing these rows.

Corrected SmolLM2 completion to 44/64 (68.75%) across all expected-positive attempts; 44/54 (81.48%) was conditional on valid extraction. Native/reference scope markers preserve the 26-row earlier native-case export, including sixteen nondeployed reference controls. Older 450/300 public-intent and nine-case external-pilot headlines remain separately tagged as unverified for their exact matching protocol. Private participant requests remain excluded from the public paper data; their aggregate history remains in the audit.
