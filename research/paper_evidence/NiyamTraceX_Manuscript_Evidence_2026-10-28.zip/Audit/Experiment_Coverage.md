# Experiment coverage and preservation

Each recovered study or attempted study has an explicit destination. Rows are not independent cohorts and must not be summed.

| ID | Study | Units | Kept in | Qualification |
|---|---|---|---|---|
| A01 | Early anchor stress | 16,800 constructed cases | S3; retained raw CSVs | Predicate agreement, not live model accuracy. |
| A02 | SIL/IIEA construction | 50,000 effect-set cases; four methods | S3; retained raw CSVs | Shared symbolic oracle; no language-model inference. |
| A03 | First execution broker | 2,500 repeated fixture trials | S3; raw trial CSV | Repeated conditions; not 2,500 independent states. |
| A04 | Statistics and generator audit | Same 2,000 outputs; archived 10,000-row corpus audit | S2/S3; audit JSON | Not a fresh model study; archived corpus audit not re-executed. |
| A05 | Frozen runtime ablation | 2,000/model, 500 groups | Article; S2 | Same stored outputs across four stages; Qwen cache reuse disclosed. |
| A06 | Metamorphic lab | 21,762 mutations/controls per detector | S4; raw JSONL | Includes 9,756 attacks; shares generated source groups. |
| A07 | Transaction-first reference broker | 1,320 scenarios | Article; S4 | 120 distinct states/arguments per condition; reference implementation. |
| A08 | Risk-selective authorization | 600 held-out cases/split; 20 splits | Article; S5 | Repeated splits overlap; five retain unsafe verdicts. |
| A09 | Anchor Lock V3 | 10,248 attacks + 2,000 controls | Article; S4 | Post-freeze hardening; 3,996 valid output replays and 3,200 benign transforms. |
| A10 | BFCL/MLCL external stage | Attempts and empty score files | S12; status records | No official authorization score. |
| A11 | AgentDojo/Agent-SafetyBench stage | Attempt/inventory records | S12; status records | File availability and failed CLI execution are not model outcomes. |
| A12 | Stateful external stage | Attempted trajectories | S12; status records | Context/API/runner failures remain unscored. |
| A13 | Unified benchmark matrix | Aggregates of available stages | S12; source matrix | Missing inputs and duplicate summaries are not new experiments. |
| AX | Wave-3 master exports | Repeated stage and status exports | Archive provenance | Re-export of earlier cohorts; not an independent replication. |
| X01 | Hosted QUICK pilot | Three domains/model; six trajectories | S12 | Ungated external harness; sparse descriptive rewards only. |
| X02 | Provider recovery preflights | Three provider-family checks | S12; archived status CSVs | HTTP 402 failures; no new inference outcomes. |
| X03 | Local GPU server attempts | Two failed startup archives | S12; source history | Infrastructure failures; no performance score. |
| X04 | Latest local T4 external pilot | Two AgentDojo rows/model; limited stateful rewards | S12; retained CSVs | Baseline/injection rows are related; no gate in callback path. |
| O06A | October 6 live baselines | 160 shared requests/model; three checkpoints | S6 | Ungated verdict baseline; non-ALLOW denominator 140. |
| O06B | October 6 live red team | 300 attacks; 12 families | Article; S7 | 198 residual-unsafe classifications, not 198 native commits. |
| O06C | October 6 stateful harness | 160 paired requests | Article; S7 | Exporter flags/effect counts; separate reference database implementation. |
| O06D | October 6 demonstration ablation | 240 demonstration requests | Companion audit; excluded | Demonstration backend; not empirical live-model validation. |
| O08A | October 8 open-weight reference study | 152 scored + 64 contrast realizations/model | Article; S8 | Three models; full/anchors/single-best have identical decisions. |
| O08B | October 8 contrasts and mutations | 32 contrast pairs/model; applicable proposal mutations | S8 | Applicability differs; zero eligible SmolLM2 negation deletions. |
| O08C | October 8 public intent diagnostic | 240 outputs/model; 24/cell | S8 | Selected classes; public intent gold is not ERP authorization gold. |
| O08D | October 8 uncertainty probe | 40 requests; four samples/request | S11 | AUC 0.475; no validated ambiguity estimator. |
| O10 | October 10 native counterexamples | Three native API/broker checks + seven pipeline probes; 16 separate reference controls | Article; S13 | Vulnerable earlier source; reference controls are not deployed mediation. |
| O11A | October 11 candidate intersection | 360/direction; six methods | Article; S9 | 4,320 method rows are correlated; preferred proposal fixed. |
| O11B | October 11 controlled subset | 240/direction; 80 groups | S9 | Nested subset of O11A, not an extra cohort. |
| O11C | October 11 public intent diagnostic | 336 outputs/model across two protocols | Article; S10 | Same dataset family as earlier diagnostic; no independent ERP labels. |
| O11D | October 11 contrasts and language agreement | 60 pairs/model; 80 three-language groups | Article; S10 | Validity and conditional agreement reported separately. |
| O11E | October 11 uncertainty probe | 30 requests; four samples/request | Article; S11 | Ten requests have no valid sample; AUC confounded by failure. |
| O11F | Selected secondary-interpretation retest | 48 previously discovered regressions | Article; S9; raw retest archive | Selected-case diagnosis, not a fresh full-cohort replication. |
| O11G | Blocked native regressions | Zero completed source assertions | S13; import-error records | Collection/probe failure is not a pass. |
| O14 | Independent-audit notebook smoke | Four demonstration examples | S15; companion audit | Input null/publication-eligible false; not model performance. |
| O17A | Annotation history | 32 requests, two supplied reviewer files | Companion private-cohort aggregate audit | Previously examined; policy/ethics documentation incomplete; excluded from paper outcomes. |
| O17B | Offline original/parser-patch diagnostic | Same 32 requests in two arms | Companion private-cohort aggregate audit | Mock parser, no positive cohort, no independent holdout after debugging. |
| O18 | Prospective policy/new-case plan | Planning/review artifacts | Coverage record; no outcome score | A proposed experiment is not an executed result. |
| O19 | Synthetic source execution smoke | Four generated fixtures | S13; SQLite/traces | Mock extractor; one positive operation; year test accepts BLOCK or CLARIFY. |
| O20 | Local native broker repair | Nine probes; 34 security regressions | Article; S13 | 18 retained before/after databases; local SQLite only; 361 retained test passes. |
| O21/22 | Earlier live private diagnostic | Same 32 requests/model | Companion private-cohort aggregate audit | No positive labels and no simulation/commit; not manuscript validation. |
| O23 | Frozen native live controlled study | 48 generated probes/model | Article; S14 | Actual inference; three Qwen unsafe commits/five row changes. |
| O23C | Known-candidate execution control | Same 48 generated probes | Article; S14 | Correct supplied candidates, not model inference. |
| O23H | Repeated private diagnostic | Same previously examined 32/model | Companion private-cohort aggregate audit | Repeated labels; no new human holdout; private text excluded. |
| L750 | Older MASSIVE/MTOP headline protocol | Reported 450/300 examples | Legacy-claim audit only | Matching original output/scorer records not recovered; no verified paper score. |
| LX | Earlier local pilot headline claims | Reported nine-case/six-trajectory variants | Legacy-claim audit only | Do not substitute these for the recovered latest T4 snapshot. |
