# Supplement LaTeX repair and final checks

The supplementary generator emitted bare percent signs in narrative paragraphs. In LaTeX, these begin comments and removed the remainder of affected source lines from the rendered supplement. The generator now escapes bare percent signs in paragraph strings while preserving existing LaTeX commands and already escaped percentages.

## Verification

- Rebuilt `Supplementary/supplement.tex` from the retained result records with `Analysis/build_supplement.py`.
- Confirmed zero unescaped percent signs remain in the generated source.
- Recompiled the 17-page supplement with `latexmk -pdf -interaction=nonstopmode -halt-on-error`.
- Extracted the PDF text and confirmed representative affected passages are present, including the 0.80% bound, 99.96% predicate agreement, generator-duplicate rates, 84.67% and 85.40% recall distinction, and native repair findings.
- Recompiled the Frontiers and Scientific Reports main manuscripts. Both compile; both contain 30 citation keys matched to 30 bibliography entries, with no missing or uncited entries and no undefined citation/reference warnings.

No experimental values were changed in this repair.
