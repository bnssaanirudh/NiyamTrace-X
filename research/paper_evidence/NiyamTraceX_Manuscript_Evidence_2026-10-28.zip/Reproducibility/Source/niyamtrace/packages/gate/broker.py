"""Authenticated, transaction-bound execution with an independent state audit."""

import time

from sqlalchemy import MetaData, select, text

from packages.contracts.schema import RecordDelta, StateDelta
from packages.gate.capability import BrokerVerificationError, digest, verify_certificate
from packages.gate.executor import ERPExecutor
from packages.gate.policy import DEFAULT_POLICY
from packages.gate.simulator import ShadowSimulator
from packages.storage.models import ConsumedCapability


def _normalized(delta):
    value = delta.model_dump(mode="json")
    value["affected_record_ids"] = sorted(value["affected_record_ids"])
    value["record_deltas"] = sorted(
        value["record_deltas"], key=lambda r: (r["table"], r["record_id"], r["field"])
    )
    value["table"] = sorted(
        value["table"] if isinstance(value["table"], list) else [value["table"]]
    )
    return value


async def _snapshot(session):
    state = {}
    metadata = MetaData()
    connection = await session.connection()
    await connection.run_sync(lambda conn: metadata.reflect(bind=conn))
    for table in metadata.sorted_tables:
        if table.name == "consumed_capabilities":
            continue
        rows = (await session.execute(select(table))).mappings().all()
        pk = [c.name for c in table.primary_key]
        if pk:
            state[table.name] = {tuple(row[k] for k in pk): dict(row) for row in rows}
        else:
            # Unchanged tables without PKs have stable multiset keys. Any insert,
            # delete or update in such a table is unexpected and fails closed.
            rows = sorted((dict(row) for row in rows), key=digest)
            state[table.name] = {(digest(row), i): row for i, row in enumerate(rows)}
    return state


def _observed_delta(before, after, table_name):
    changes = []
    for table, old_rows in before.items():
        new_rows = after[table]
        if old_rows.keys() != new_rows.keys():
            raise BrokerVerificationError("State mismatch: unexpected inserted/deleted records")
        for key, old in old_rows.items():
            new = new_rows[key]
            for field, old_value in old.items():
                if old_value != new[field]:
                    changes.append(
                        RecordDelta(
                            record_id=str(key[0]),
                            table=table,
                            field=field,
                            old_value=old_value,
                            new_value=new[field],
                        )
                    )
    return StateDelta(
        affected_record_ids=sorted({c.record_id for c in changes}),
        record_deltas=changes,
        table=table_name,
        estimated_row_count=len({(c.table, c.record_id) for c in changes}),
    )


class VerifiedExecutionBroker:
    def __init__(self, session, policy=DEFAULT_POLICY):
        self._session = session
        self._executor = ERPExecutor(session)
        self._policy = policy

    async def commit(self, cert, tool_call, auth_context):
        session = self._session
        try:
            if session.get_bind().dialect.name == "sqlite":
                if not session.in_transaction():
                    await session.execute(text("BEGIN IMMEDIATE"))
                await session.execute(
                    text("UPDATE consumed_capabilities SET nonce=nonce WHERE 1=0")
                )
            elif session.get_bind().dialect.name == "postgresql":
                isolation = (await session.execute(text("SHOW transaction_isolation"))).scalar_one()
                if isolation != "serializable":
                    raise BrokerVerificationError("Broker requires a serializable transaction")
            else:
                raise BrokerVerificationError("Unsupported database transaction semantics")
            self._policy.loader.load()
            verify_certificate(cert, tool_call, auth_context, self._policy.policy_hash)
            if await session.get(ConsumedCapability, cert.nonce) is not None:
                raise BrokerVerificationError("Replay: capability already consumed")
            expected = StateDelta.model_validate(cert.predicted_delta.get("state_delta", {}))
            current = await ShadowSimulator(session).predict(tool_call)
            if _normalized(current) != _normalized(expected):
                raise BrokerVerificationError("State mismatch: stale authorized effect set")
            before = await _snapshot(session)
            ledger_before = {
                row.nonce: (row.actor, row.consumed_at)
                for row in (await session.execute(select(ConsumedCapability))).scalars()
            }
            consumed_at = time.time()
            session.add(
                ConsumedCapability(nonce=cert.nonce, actor=cert.actor, consumed_at=consumed_at)
            )
            await session.flush()
            session.info["_niyam_execution_grant"] = (
                tool_call.tool_name,
                digest(tool_call.arguments),
            )
            try:
                reported = await self._executor.execute(tool_call)
            finally:
                session.info.pop("_niyam_execution_grant", None)
            after = await _snapshot(session)
            ledger_after = {
                tuple(row)
                for row in (
                    await session.execute(
                        select(
                            ConsumedCapability.nonce,
                            ConsumedCapability.actor,
                            ConsumedCapability.consumed_at,
                        )
                    )
                ).all()
            }
            expected_ledger = {
                (nonce, actor, stamp) for nonce, (actor, stamp) in ledger_before.items()
            }
            expected_ledger.add((cert.nonce, cert.actor, consumed_at))
            if ledger_after != expected_ledger:
                raise BrokerVerificationError(
                    "State mismatch: capability ledger changed unexpectedly"
                )
            observed = _observed_delta(before, after, expected.table)
            if _normalized(observed) != _normalized(expected) or _normalized(
                reported
            ) != _normalized(expected):
                raise BrokerVerificationError(
                    "State mismatch: actual database effects differ from authorization"
                )
            self._policy.loader.load()
            verify_certificate(cert, tool_call, auth_context, self._policy.policy_hash)
            session.info.setdefault("_niyam_pending_capabilities", []).append(
                (
                    cert.model_copy(deep=True),
                    tool_call.model_copy(deep=True),
                    auth_context.model_copy(deep=True),
                    self._policy,
                )
            )
            return observed
        except Exception:
            session.info.pop("_niyam_execution_grant", None)
            await session.rollback()
            raise
