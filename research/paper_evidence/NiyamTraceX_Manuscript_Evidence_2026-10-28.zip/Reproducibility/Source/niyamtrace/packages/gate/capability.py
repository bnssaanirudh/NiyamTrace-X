"""Server-authenticated capabilities for the trusted gate/broker process.

This protects API callers and untrusted model outputs, not arbitrary Python code
with access to server memory, signing keys, or direct database credentials.
"""

import hashlib
import hmac
import json
import os
import secrets
import time


class BrokerVerificationError(Exception):
    pass


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=str)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def _key():
    configured = os.environ.get("NIYAM_CAPABILITY_KEY")
    if configured:
        if len(configured.encode()) < 32:
            raise BrokerVerificationError("NIYAM_CAPABILITY_KEY must contain at least 32 bytes")
        return configured.encode()
    if os.environ.get("ENVIRONMENT", "development") == "production":
        raise BrokerVerificationError("NIYAM_CAPABILITY_KEY is required in production")
    return _DEVELOPMENT_KEY


_DEVELOPMENT_KEY = secrets.token_bytes(32)


def _signature(cert):
    payload = cert.model_dump(mode="json", exclude={"signature"})
    return hmac.new(_key(), canonical(payload).encode(), hashlib.sha256).hexdigest()


def _issue_certificate(cert, tool_call, auth_context, policy_hash):
    if auth_context is None:
        return cert.seal()  # audit-only decision; cannot authorize a write
    cert.issuer = "NiyamGate-v3"
    cert.tenant_id = auth_context.tenant_id
    cert.nonce = secrets.token_hex(32)
    cert.expires_at = time.time() + 60
    cert.arguments_hash = digest(tool_call.model_dump(mode="json"))
    cert.authorization_hash = digest(auth_context.model_dump(mode="json"))
    cert.policy_hash = policy_hash
    cert.seal()
    cert.signature = _signature(cert)
    return cert


def verify_certificate(cert, tool_call, auth_context, policy_hash=None):
    if cert is None or not cert.verify():
        raise BrokerVerificationError("Certificate integrity check failed (tampered)")
    if (
        cert.issuer != "NiyamGate-v3"
        or not cert.signature
        or not hmac.compare_digest(cert.signature, _signature(cert))
    ):
        raise BrokerVerificationError("Certificate origin is not authenticated by NiyamGate")
    if auth_context is None or cert.actor != auth_context.subject:
        raise BrokerVerificationError("Actor identity mismatch")
    if cert.tenant_id != auth_context.tenant_id:
        raise BrokerVerificationError("Tenant mismatch")
    if cert.authorization_hash != digest(auth_context.model_dump(mode="json")):
        raise BrokerVerificationError("Authorization context changed")
    if (
        cert.arguments_hash != digest(tool_call.model_dump(mode="json"))
        or cert.target_type != tool_call.tool_name
    ):
        raise BrokerVerificationError("Tool or arguments mismatch")
    if not cert.nonce or cert.expires_at <= time.time() or cert.gate_decision != "ALLOW":
        raise BrokerVerificationError("Capability expired or not executable")
    if policy_hash is not None and cert.policy_hash != policy_hash:
        raise BrokerVerificationError("Policy changed")


def require_broker_execution(session, tool_name, arguments):
    grant = session.info.get("_niyam_execution_grant")
    if not grant or grant != (tool_name, digest(arguments)):
        raise BrokerVerificationError("Execution requires an active verified broker authorization")


# Recheck leases at the actual transaction commit boundary, including callers
# that use AsyncSession.commit directly instead of SessionManager.
from sqlalchemy import event, select
from sqlalchemy.orm import Session


@event.listens_for(Session, "before_commit")
def _verify_at_commit(session):
    from packages.storage.models import ConsumedCapability

    for cert, tool_call, auth_context, policy in session.info.get(
        "_niyam_pending_capabilities", []
    ):
        policy.loader.load()
        verify_certificate(cert, tool_call, auth_context, policy.policy_hash)
        row = session.execute(
            select(ConsumedCapability).where(ConsumedCapability.nonce == cert.nonce)
        ).scalar_one_or_none()
        if row is None or row.actor != cert.actor:
            raise BrokerVerificationError("Capability ledger missing at commit")


@event.listens_for(Session, "after_commit")
@event.listens_for(Session, "after_rollback")
def _clear_commit_verifications(session):
    session.info.pop("_niyam_pending_capabilities", None)
