"""
packages/nlp/language_id.py — Language and Script Identification

Detects the language and script of input text using span-based methods.
Extracts protected spans first, then runs IndicLID on linguistic spans.

Supported output languages (IndicLID conventions):
  "eng_Latn"  — English
  "hin_Latn"  — Hinglish (Hindi written in Latin script)
  "tel_Telu"  — Telugu script
  "tel_Latn"  — Romanized Telugu
"""

from __future__ import annotations

import re
from typing import Any

# ---------------------------------------------------------------------------
# Regex patterns for protected spans
# ---------------------------------------------------------------------------

_PATTERNS = {
    "url": r"https?://\S+|www\.\S+",
    "email": r"\S+@\S+\.\S+",
    "protected_identifier": r"(?<!\w)(?:INV|USR|SR|REQ|TKT)[-_A-Za-z0-9/]+",
    "number": r"\b\d+(?:,\d+)*(?:\.\d+)?\b",

    "money": r"(?:₹|\$|€|£)\s*\d+(?:,\d+)*(?:\.\d+)?",
    "quoted_string": r'"[^"]*"|\'[^\']*\'',
    "date": r"\b\d{1,4}[-/]\d{1,2}[-/]\d{1,4}\b",

}

# Combine all patterns into a single regex with named groups
_COMBINED_PATTERN = re.compile(
    "|".join(f"(?P<{name}>{pattern})" for name, pattern in _PATTERNS.items())
)

class IndicLIDWrapper:
    """
    Wrapper for AI4Bharat IndicLID model.

    Behaviour:
      - If INDICLID_MODEL_DIR env var is set AND the AI4Bharat
        'Bhasha-Abhijnaanam' package is importable, the real model is loaded.
      - Otherwise, falls back to the heuristic detector so that tests and CI
        continue to work without the ~2 GB model download.

    Set env var: INDICLID_MODEL_DIR=/path/to/indiclid_model
    """

    def __init__(self, model_dir: str | None = None) -> None:
        import os
        self._using_real_model = False
        self._lid_model = None

        resolved_dir = model_dir or os.environ.get("INDICLID_MODEL_DIR")
        if resolved_dir:
            try:
                from ai4bharat.transliteration import XlitEngine  # noqa: F401 — import check

                # IndicLID uses a separate inference class from the same org
                from IndicBert import IndicLID as _IndicLID  # type: ignore[import]
                self._lid_model = _IndicLID(model_path=resolved_dir)
                self._using_real_model = True
                import logging
                logging.getLogger(__name__).info(
                    "IndicLID: real model loaded from %s", resolved_dir
                )
            except Exception as exc:
                import logging
                logging.getLogger(__name__).warning(
                    "IndicLID: could not load real model (%s). "
                    "Using heuristic fallback.", exc
                )
        else:
            import logging
            logging.getLogger(__name__).debug(
                "IndicLID: INDICLID_MODEL_DIR not set — using heuristic fallback."
            )

    def predict(self, text: str) -> tuple[str, str, float]:
        """
        Returns (language_tag, script, confidence).
        Language tags follow IndicLID conventions:
            eng_Latn, hin_Latn, tel_Telu, tel_Latn.
        """
        if self._using_real_model and self._lid_model is not None:
            return self._predict_real(text)
        return self._predict_heuristic(text)

    def _predict_real(self, text: str) -> tuple[str, str, float]:
        """Run inference via the real AI4Bharat IndicLID model."""
        try:
            result = self._lid_model.predict(text)
            # IndicLID returns a list of (lang_tag, confidence) tuples
            if result and isinstance(result, (list, tuple)):
                lang_tag, conf = result[0] if isinstance(result[0], (list, tuple)) else result
                script = "telugu" if "Telu" in str(lang_tag) else "latin"
                return str(lang_tag), script, float(conf)
        except Exception:
            pass
        return self._predict_heuristic(text)

    def _predict_heuristic(self, text: str) -> tuple[str, str, float]:
        """Deterministic heuristic fallback — no model required."""
        text_lower = text.lower()
        if re.search(r"[\u0C00-\u0C7F]", text):
            return "tel_Telu", "telugu", 0.99
        if any(w in text_lower for w in [
            "ki", "ni", "vacche", "rojula", "paatu", "cheyyi",
            "cheyyaku", "cheyyandi", "garu",
        ]):
            return "tel_Latn", "latin", 0.91
        if any(w in text_lower for w in [
            "ka", "agle", "din", "ke", "liye", "karo",
            "pichle", "mahine", "saare",
        ]):
            return "hin_Latn", "latin", 0.92
        if any(w in text_lower for w in [
            "block", "access", "next", "days", "change", "limit",
            "archive", "invoice", "vendor", "update", "suspend",
        ]):
            return "eng_Latn", "latin", 0.95
        return "unknown", "latin", 0.0

class LanguageIdentifier:
    """
    Span-level language identifier for NiyamTrace.
    Preserves raw text, extracts non-linguistic spans, runs LID on remainder.
    """

    def __init__(self, model_dir: str | None = None):
        self.lid = IndicLIDWrapper(model_dir)

    def identify(self, text: str) -> dict[str, Any]:
        """
        Returns structured output with spans, primary_language_mix, and requires_review.
        """
        spans = []
        last_end = 0
        
        # Iterate over all protected matches
        for match in _COMBINED_PATTERN.finditer(text):
            start = match.start()
            end = match.end()
            
            # Linguistic span before the match
            if start > last_end:
                linguistic_text = text[last_end:start]
                if linguistic_text.strip():
                    lang, script, conf = self.lid.predict(linguistic_text)
                    spans.append({
                        "text": linguistic_text,
                        "type": "linguistic",
                        "language": lang,
                        "script": script,
                        "confidence": conf
                    })
            
            # Protected span
            span_type = match.lastgroup
            spans.append({
                "text": match.group(),
                "type": span_type,
                "language": "none",
                "script": "latin",
                "confidence": 1.0
            })
            
            last_end = end
            
        # Remaining linguistic span
        if last_end < len(text):
            linguistic_text = text[last_end:]
            if linguistic_text.strip():
                lang, script, conf = self.lid.predict(linguistic_text)
                spans.append({
                    "text": linguistic_text,
                    "type": "linguistic",
                    "language": lang,
                    "script": script,
                    "confidence": conf
                })

        # Calculate primary language mix
        langs = set()
        for span in spans:
            if span["type"] == "linguistic" and span["language"] != "unknown":
                langs.add(span["language"])
        
        primary_language_mix = list(langs)
        if not primary_language_mix:
            primary_language_mix = ["eng_Latn"] # default

        # Sort for deterministic output
        primary_language_mix.sort(reverse=True)

        scripts = set()
        confidences = []
        for span in spans:
            if span["type"] == "linguistic":
                scripts.add(span["script"])
                confidences.append(span["confidence"])
        
        if not scripts:
            script_val = "Latin"
        elif "telugu" in scripts and "latin" in scripts:
            script_val = "Mixed"
        elif "telugu" in scripts:
            script_val = "Telugu"
        else:
            script_val = "Latin"

        code_switched = len(primary_language_mix) > 1 or "hin_Latn" in primary_language_mix
        avg_confidence = sum(confidences) / len(confidences) if confidences else 1.0

        return {
            "raw_text": text,
            "spans": spans,
            "primary_lang": primary_language_mix[0] if primary_language_mix else "eng_Latn",
            "primary_language_mix": primary_language_mix,
            "script": script_val,
            "code_switched": code_switched,
            "confidence": avg_confidence,
            "requires_review": "unknown" in langs or any(s["confidence"] < 0.5 for s in spans if s["type"] == "linguistic")
        }


