"""Require positive calendar context for a year in the original request."""

import re

from packages.nlp.temporal import TemporalDeicticsResolver

_MONTHS = (
    "january|february|march|april|may|june|july|august|september|october|november|december|"
    "జనవరి|ఫిబ్రవరి|మార్చి|ఏప్రిల్|మే|జూన్|జూలై|ఆగస్టు|సెప్టెంబర్|అక్టోబర్|నవంబర్|డిసెంబర్"
)
_YEAR = r"(?:19|20|21)\d{2}"
_FORWARD = re.compile(
    r"(?<!\w)(?:" + _MONTHS + r")(?:\s+(?:of|in))?\s*[,/-]?\s*(?P<year>" + _YEAR + r")(?!\d)",
    re.IGNORECASE,
)
_REVERSE = re.compile(
    r"(?<!\d)(?P<year>" + _YEAR + r")\s*[,/-]?\s*(?:" + _MONTHS + r")(?!\w)", re.IGNORECASE
)
_EXPLICIT = re.compile(
    r"(?:\byear\b|సంవత్సరం|సంవత్సరపు|సాల్|\bsaal\b)\s*[:=]?\s*(?P<year>" + _YEAR + r")(?!\d)",
    re.IGNORECASE,
)
_ISO = re.compile(
    r"(?<![\w-])(?P<year>"
    + _YEAR
    + r")[-/](?:0?[1-9]|1[0-2])(?:[-/](?:0?[1-9]|[12]\d|3[01]))?(?!\d)"
)
_IDENTITY = re.compile(
    r"(?:vendor|supplier|employee|user|invoice|id|వెండర్|విక్రేత|సరఫరాదారు)\s*(?:(?:id|number|no\.?|#)\s*)?[:=\-]?\s*(\d+)",
    re.IGNORECASE,
)
_RELATIVE_MONTH = re.compile(
    r"\b(?:this|last|next|current)\s+month\b|\b(?:is|pichle?|agle)\s+mahine?\b|\b(?:ee|pindi|tarvata|modutu)\s+nela\b|(?:ఈ|గత|వచ్చే)\s*నెల",
    re.IGNORECASE,
)


def archive_year_is_grounded(raw_text, year, reference_datetime=None):
    text = str(raw_text)
    identities = [m.span(1) for m in _IDENTITY.finditer(text)]
    years = set()
    for pattern in (_FORWARD, _REVERSE, _EXPLICIT, _ISO):
        for match in pattern.finditer(text):
            start = match.start("year")
            if not any(a <= start < b for a, b in identities):
                years.add(int(match.group("year")))
    if years:
        # Once a calendar anchor exists, additional year-like values cannot be
        # silently dropped from a wider or ambiguous request (2025 or 2026).
        all_years = {
            int(m.group())
            for m in re.finditer(r"(?<!\d)" + _YEAR + r"(?!\d)", text)
            if not any(a <= m.start() < b for a, b in identities)
        }
        return years == {year} and all_years == {year}
    if reference_datetime is not None and _RELATIVE_MONTH.search(text):
        resolved = TemporalDeicticsResolver(reference_dt=reference_datetime).resolve(text)
        return resolved is not None and resolved.year == year
    return False
