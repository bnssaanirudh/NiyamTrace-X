"""Synthetic native-source security probes with retained SQLite and JSONL evidence.
No LLM inference or human-label evaluation is performed.
"""

import os

os.environ.setdefault("LLM_BACKEND", "groq")
os.environ.setdefault("GROQ_API_KEY", "offline-fixture-key-not-used")
import argparse
import asyncio
import hashlib
import json
import sqlite3
import subprocess
import time
from pathlib import Path

from sqlalchemy import update
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine

from apps.gateway.pipeline import NiyamPipeline, PipelineRequest
from data.synthetic.erp import seed_fresh_async
from packages.auth.models import AuthorizationContext, Principal
from packages.contracts.schema import ActionContract, EffectCertificate, ToolCall
from packages.gate.broker import BrokerVerificationError, VerifiedExecutionBroker
from packages.gate.executor import ERPExecutor
from packages.gate.gate import NiyamGate
from packages.gate.simulator import ShadowSimulator
from packages.nlp.compiler import CandidateIntent, CandidateSlots, NiyamCompiler
from packages.policy.compiler import PolicyCompiler
from packages.policy.loader import PolicyLoader
from packages.storage.models import VendorInvoice

AUTH = AuthorizationContext.from_principal(
    Principal(
        subject="native-security",
        tenant_id="acme",
        roles=frozenset({"procurement_manager"}),
        scopes=frozenset({"procurement.write"}),
    )
)
CALL = ToolCall(
    tool_name="archive_invoices", arguments={"vendor_id": 4421, "month": 3, "year": 2025}
)
RAW = "Archive March 2025 invoices for vendor 4421"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def snapshot(path, dest):
    with sqlite3.connect(path) as db, sqlite3.connect(dest) as out:
        db.backup(out)
    with sqlite3.connect(dest) as db:
        tables = [
            r[0]
            for r in db.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"
            )
        ]
        result = {}
        for table in tables:
            quoted = '"' + table.replace('"', '""') + '"'
            cols = [x[1] for x in db.execute("PRAGMA table_info(" + quoted + ")")]
            rows = [dict(zip(cols, r)) for r in db.execute("SELECT * FROM " + quoted)]
            result[table] = sorted(rows, key=lambda r: json.dumps(r, sort_keys=True))
        return result


def differences(before, after):
    result = {}
    for table in sorted(set(before) | set(after)):
        b = {json.dumps(r, sort_keys=True) for r in before.get(table, [])}
        a = {json.dumps(r, sort_keys=True) for r in after.get(table, [])}
        result[table] = {
            "removed": [json.loads(r) for r in sorted(b - a)],
            "added": [json.loads(r) for r in sorted(a - b)],
        }
    return result


async def run_probe(out, probe, kind):
    folder = out / probe
    folder.mkdir(parents=True, exist_ok=False)
    database = folder / "erp.sqlite"
    engine = create_async_engine("sqlite+aiosqlite:///" + str(database))
    await seed_fresh_async(engine)
    entrypoint = ""
    cert = None
    decision = None
    reason = None
    policy = None
    auth = AUTH
    before = None
    try:
        if kind in {"positive", "missing_year", "viewer", "tenant"}:
            raw = RAW if kind != "missing_year" else "Archive March invoices for vendor 4421"
            if kind == "viewer":
                auth = AUTH.model_copy(update={"roles": frozenset({"viewer"})})
            if kind == "tenant":
                auth = AUTH.model_copy(update={"tenant_id": "other"})
            compiler = NiyamCompiler(parser_version_suffix="native-controlled-fixture")
            compiler._extract_candidate = lambda *args, **kwargs: CandidateIntent(
                intent="invoice.archive",
                slots=CandidateSlots(VENDOR_ID="4421", MONTH=3, YEAR=2025),
                confidence=1,
            )
            before = snapshot(database, folder / "before.sqlite")
            pipeline = NiyamPipeline(engine=engine, traces_dir=folder / "traces", compiler=compiler)
            entrypoint = "apps.gateway.pipeline.NiyamPipeline.run"
            result = await pipeline.run(
                PipelineRequest(
                    raw_text=raw,
                    actor_id=auth.subject,
                    actor_role=auth.display_role,
                    auth_context=auth,
                )
            )
            decision = result.gate_decision.verdict
            reason = result.gate_decision.reason_code
            trace = result.trace_path
        else:
            async with AsyncSession(engine, expire_on_commit=False) as session:
                predicted = await ShadowSimulator(session).predict(CALL)
                c = ActionContract(
                    actor_id=AUTH.subject,
                    actor_role=AUTH.display_role,
                    intent="invoice.archive",
                    intent_confidence=1,
                    slots={"VENDOR_ID": 4421, "MONTH": 3, "YEAR": 2025},
                    raw_text=RAW,
                    normalized_text=RAW,
                )
                if kind == "policy":
                    p = folder / "policy.yaml"
                    p.write_text(Path("policies/reference.yaml").read_text())
                    policy = PolicyCompiler(PolicyLoader(str(p)))
                    gate = NiyamGate(policy)
                else:
                    gate = NiyamGate()
                cert = gate.evaluate(c, predicted, CALL, auth_context=AUTH).effect_certificate
                if kind == "forged":
                    cert = EffectCertificate(
                        trace_id="self-sealed-forgery",
                        actor=AUTH.subject,
                        action="invoice.archive",
                        target_type=CALL.tool_name,
                        selector=c.slots,
                        policy_rules_used=[],
                        evidence_refs=[],
                        predicted_delta={"record_ids": predicted.affected_record_ids},
                    ).seal()
                if kind == "replay":
                    await VerifiedExecutionBroker(session).commit(cert, CALL, AUTH)
                    await session.commit()
                elif kind == "stale":
                    await session.execute(
                        update(VendorInvoice)
                        .where(VendorInvoice.invoice_id == "INV-4421-2503")
                        .values(status="PAID")
                    )
                    await session.commit()
                else:
                    await session.rollback()
                if kind == "policy":
                    p.write_text(p.read_text().replace('version: "1.0.0"', 'version: "revoked"'))
                before = snapshot(database, folder / "before.sqlite")
                trace = folder / "native_probe.jsonl"
                events = [
                    {
                        "event": "probe_started",
                        "probe_id": probe,
                        "time": time.time(),
                        "controlled_model_backend": False,
                    }
                ]
                try:
                    if kind == "direct":
                        entrypoint = "packages.gate.executor.ERPExecutor.execute"
                        await ERPExecutor(session).execute(CALL)
                    else:
                        entrypoint = "packages.gate.broker.VerifiedExecutionBroker.commit"
                        broker = (
                            VerifiedExecutionBroker(session, policy)
                            if policy
                            else VerifiedExecutionBroker(session)
                        )
                        await broker.commit(cert, CALL, AUTH)
                    await session.commit()
                    decision = "ALLOW"
                    reason = "COMMITTED"
                except BrokerVerificationError as error:
                    await session.rollback()
                    decision = "BLOCK"
                    reason = str(error)
                events.append(
                    {
                        "event": "probe_completed",
                        "decision": decision,
                        "reason": reason,
                        "entrypoint": entrypoint,
                        "time": time.time(),
                    }
                )
                trace.write_text("\n".join(json.dumps(e, sort_keys=True) for e in events) + "\n")
        after = snapshot(database, folder / "after.sqlite")
        diff = differences(before, after)
        business_tables = {"vendor_invoices", "vendor_credit_limits", "user_access"}
        changed = sum(len(diff[t]["removed"]) for t in business_tables)
        if kind == "positive":
            passed = (
                decision == "ALLOW" and changed == 3 and len(diff["vendor_invoices"]["added"]) == 3
            )
        else:
            passed = decision in {"BLOCK", "CLARIFY"} and changed == 0 and before == after
        (folder / "database_diff.json").write_text(json.dumps(diff, indent=2))
        record = {
            "id": probe,
            "status": "PASS" if passed else "FAIL",
            "actual_native_executor": True,
            "entrypoint": entrypoint,
            "decision": decision,
            "reason": reason,
            "rows_mutated": changed,
            "trace_path": str(trace.relative_to(out)),
            "trace_sha256": sha(trace),
            "before_db_path": str((folder / "before.sqlite").relative_to(out)),
            "before_db_sha256": sha(folder / "before.sqlite"),
            "after_db_path": str((folder / "after.sqlite").relative_to(out)),
            "after_db_sha256": sha(folder / "after.sqlite"),
        }
        return record
    finally:
        await engine.dispose()


async def main(out):
    out.mkdir(parents=True, exist_ok=False)
    fixtures = [
        ("SEC-01_DIRECT_EXECUTOR_MEDIATION", "direct"),
        ("SEC-02_CERTIFICATE_ORIGIN_BINDING", "forged"),
        ("SEC-03_MISSING_YEAR", "missing_year"),
        ("SEC-04_PAIRED_BROKER_POSITIVE", "positive"),
        ("SEC-REPLAY", "replay"),
        ("SEC-STALE_STATE", "stale"),
        ("SEC-WRONG_TENANT", "tenant"),
        ("SEC-POLICY_REVOKE", "policy"),
        ("SEC-UNAUTHORIZED_VIEWER", "viewer"),
    ]
    records = []
    for probe, kind in fixtures:
        try:
            r = await run_probe(out, probe, kind)
        except Exception as e:  # noqa: BLE001 - preserve errors as measured outcomes
            r = {"id": probe, "status": "ERROR", "error": type(e).__name__ + ": " + str(e)}
        records.append(r)
        print(probe, r["status"], r.get("decision"), r.get("rows_mutated"))
    commit = (
        await asyncio.to_thread(subprocess.check_output, ["git", "rev-parse", "HEAD"], text=True)
    ).strip()
    source_files = (
        list(Path("packages").rglob("*.py"))
        + list(Path("apps").rglob("*.py"))
        + list(Path("policies").glob("*.yaml"))
        + [Path(__file__)]
    )
    source_hashes = {str(p.resolve().relative_to(Path.cwd())): sha(p) for p in source_files}
    (out / "SOURCE_SHA256_MANIFEST.json").write_text(
        json.dumps(source_hashes, indent=2, sort_keys=True)
    )
    dirty = (
        await asyncio.to_thread(
            subprocess.check_output, ["git", "status", "--porcelain"], text=True
        )
    ).strip()
    report = {
        "working_tree_dirty": bool(dirty),
        "source_hash_manifest": "SOURCE_SHA256_MANIFEST.json",
        "repo_commit": commit,
        "study_type": "synthetic_native_security",
        "model_backend": "controlled_test_extractor_no_live_model",
        "database_backend": "SQLite",
        "production_deployment_verified": False,
        "independent_human_evaluation": False,
        "probes": records,
        "all_probes_passed": all(r["status"] == "PASS" for r in records),
    }
    (out / "PRODUCTION_FIX_EVIDENCE.json").write_text(json.dumps(report, indent=2))
    files = {str(p.relative_to(out)): sha(p) for p in out.rglob("*") if p.is_file()}
    (out / "SHA256_MANIFEST.json").write_text(json.dumps(files, indent=2, sort_keys=True))
    if not report["all_probes_passed"]:
        raise SystemExit("Native probes contain failures/errors; raw outputs retained")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    asyncio.run(main(args.out))
