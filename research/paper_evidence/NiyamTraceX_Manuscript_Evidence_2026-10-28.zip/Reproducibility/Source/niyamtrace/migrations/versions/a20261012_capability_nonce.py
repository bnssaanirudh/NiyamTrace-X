"""Persist consumed execution capabilities atomically with ERP writes."""

import sqlalchemy as sa
from alembic import op

revision = "a20261012_nonce"
down_revision = "e1210db50de8"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "consumed_capabilities",
        sa.Column("nonce", sa.String(), primary_key=True),
        sa.Column("actor", sa.String(), nullable=False),
        sa.Column("consumed_at", sa.Float(), nullable=False),
    )


def downgrade():
    op.drop_table("consumed_capabilities")
