import os,sys,subprocess,json
from pathlib import Path
from datetime import datetime,timezone
import pytest
from sqlalchemy.ext.asyncio import create_async_engine
from packages.auth.models import Principal,AuthorizationContext
from packages.contracts.schema import ActionContract
from packages.nlp.compiler import NiyamCompiler,CandidateIntent,CandidateSlots
from apps.gateway.pipeline import NiyamPipeline,PipelineRequest,_build_tool_calls
from data.synthetic.erp import seed_fresh_async

def test_policy_hash_does_not_depend_on_python_hash_seed():
    code="from packages.policy.loader import PolicyLoader;print(PolicyLoader('policies/reference.yaml').bundle_hash)"
    hashes=[]
    for seed in ['1','2','3','123']:
        env=os.environ.copy();env['PYTHONHASHSEED']=seed
        hashes.append(subprocess.check_output([sys.executable,'-c',code],env=env,cwd=Path(__file__).resolve().parents[2],text=True).strip())
    assert len(set(hashes))==1,hashes

def test_limit_arguments_exclude_unrelated_month():
    contract=ActionContract(actor_id='test',actor_role='finance_admin',intent='limit.update',intent_confidence=0.99,slots={'VENDOR_ID':4421,'NEW_LIMIT_INR':1000,'MONTH':3,'YEAR':2025},raw_text='Set vendor 4421 credit limit to 1000 INR',normalized_text='Set vendor 4421 credit limit to 1000 INR',language_profile={},parser_version='test')
    assert _build_tool_calls(contract)[0].arguments=={'vendor_id':4421,'new_limit_inr':1000.0}

@pytest.mark.asyncio
async def test_actual_native_archive_allow_and_viewer_denial(tmp_path):
    for role,expected in [('procurement_manager','ALLOW'),('viewer','BLOCK')]:
        db=tmp_path/(role+'.sqlite');engine=create_async_engine('sqlite+aiosqlite:///'+str(db))
        try:
            await seed_fresh_async(engine)
            compiler=NiyamCompiler(parser_version_suffix='readiness-test',tenant_id='acme')
            compiler._extract_candidate=lambda *a,**k:CandidateIntent(intent='invoice.archive',slots=CandidateSlots(VENDOR_ID='4421',MONTH=3,YEAR=2025),confidence=0.99)
            principal=Principal(subject='test',tenant_id='acme',roles=frozenset({role}),scopes=frozenset({'all'}))
            result=await NiyamPipeline(engine=engine,compiler=compiler,traces_dir=tmp_path/role).run(PipelineRequest(raw_text='Archive March 2025 invoices for vendor 4421',actor_id='test',actor_role=role,reference_dt=datetime(2026,10,12,tzinfo=timezone.utc),auth_context=AuthorizationContext.from_principal(principal)))
            assert result.gate_decision.verdict==expected,result.gate_decision
            if expected=='ALLOW':
                assert set(result.actual_delta.affected_record_ids)=={'INV-4421-2503','INV-4421-2504','INV-4421-2505'}
                assert any(e.event_type=='tool_simulated' for e in result.events)
            else:assert result.actual_delta is None
        finally:await engine.dispose()
