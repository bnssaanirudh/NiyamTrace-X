"""Real database regressions for the public gate/executor/broker boundary."""

import pytest
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from data.synthetic.erp import seed_fresh_async
from packages.auth.models import Principal, AuthorizationContext
from packages.contracts.schema import ActionContract, EffectCertificate, ToolCall
from packages.gate.broker import VerifiedExecutionBroker, BrokerVerificationError
from packages.gate.executor import ERPExecutor
from packages.gate.gate import NiyamGate
from packages.gate.simulator import ShadowSimulator
from packages.storage.models import VendorInvoice

AUTH = AuthorizationContext.from_principal(
    Principal(
        subject="security-test",
        tenant_id="acme",
        roles=frozenset({"procurement_manager"}),
        scopes=frozenset({"procurement.write"}),
    )
)
CALL = ToolCall(
    tool_name="archive_invoices", arguments={"vendor_id": 4421, "month": 3, "year": 2025}
)


def contract(raw="Archive March 2025 invoices for vendor 4421"):
    return ActionContract(
        actor_id=AUTH.subject,
        actor_role=AUTH.display_role,
        intent="invoice.archive",
        intent_confidence=1,
        slots={"VENDOR_ID": 4421, "MONTH": 3, "YEAR": 2025},
        raw_text=raw,
        normalized_text=raw,
    )


@pytest.fixture
async def db(tmp_path):
    engine = create_async_engine("sqlite+aiosqlite:///" + str(tmp_path / "erp.sqlite"))
    await seed_fresh_async(engine)
    async with AsyncSession(engine, expire_on_commit=False) as session:
        yield session
    await engine.dispose()


async def state(db):
    return [
        tuple(r)
        for r in (await db.execute(select(VendorInvoice).order_by(VendorInvoice.invoice_id)))
        .scalars()
        .all()
        for r in [tuple(getattr(r, c.name) for c in VendorInvoice.__table__.columns)]
    ]


async def authorize(db, raw="Archive March 2025 invoices for vendor 4421"):
    delta = await ShadowSimulator(db).predict(CALL)
    decision = NiyamGate().evaluate(contract(raw), delta, CALL, auth_context=AUTH)
    return decision, delta


async def test_direct_executor_requires_broker_authorization(db):
    before = await state(db)
    with pytest.raises(BrokerVerificationError):
        await ERPExecutor(db).execute(CALL)
    assert await state(db) == before


async def test_public_self_seal_cannot_authorize(db):
    before = await state(db)
    _, delta = await authorize(db)
    forged = EffectCertificate(
        trace_id="forged",
        actor=AUTH.subject,
        action="invoice.archive",
        target_type=CALL.tool_name,
        selector=contract().slots,
        policy_rules_used=[],
        evidence_refs=[],
        predicted_delta={"record_ids": delta.affected_record_ids},
    ).seal()
    with pytest.raises(BrokerVerificationError):
        await VerifiedExecutionBroker(db).commit(forged, CALL, AUTH)
    assert await state(db) == before


async def test_missing_year_cannot_be_filled_by_model(db):
    decision, _ = await authorize(db, "Archive March invoices for vendor 4421")
    assert decision.verdict in {"CLARIFY", "BLOCK"}
    assert decision.effect_certificate is None


async def test_authorized_real_write_and_persistent_replay_denial(db):
    decision, delta = await authorize(db)
    assert decision.verdict == "ALLOW"
    assert len(delta.affected_record_ids) == 3
    await VerifiedExecutionBroker(db).commit(decision.effect_certificate, CALL, AUTH)
    await db.commit()
    before = await state(db)
    with pytest.raises(BrokerVerificationError):
        await VerifiedExecutionBroker(db).commit(decision.effect_certificate, CALL, AUTH)
    assert await state(db) == before


async def test_argument_binding(db):
    decision, _ = await authorize(db)
    before = await state(db)
    bad = CALL.model_copy(update={"arguments": {"vendor_id": 4421, "month": 4, "year": 2025}})
    with pytest.raises(BrokerVerificationError):
        await VerifiedExecutionBroker(db).commit(decision.effect_certificate, bad, AUTH)
    assert await state(db) == before


async def test_direct_registered_tool_requires_broker(db):
    from packages.tools.registry import get_tool_implementation

    before = await state(db)
    with pytest.raises(BrokerVerificationError):
        await get_tool_implementation(CALL.tool_name).execute(db, CALL.arguments)
    assert await state(db) == before


@pytest.mark.parametrize(
    "field,value", [("tenant_id", "other"), ("subject", "other"), ("roles", frozenset({"viewer"}))]
)
async def test_bound_authorization_context(db, field, value):
    decision, _ = await authorize(db)
    before = await state(db)
    bad = AUTH.model_copy(update={field: value})
    with pytest.raises(BrokerVerificationError):
        await VerifiedExecutionBroker(db).commit(decision.effect_certificate, CALL, bad)
    assert await state(db) == before


async def test_wrong_tool_binding(db):
    decision, _ = await authorize(db)
    before = await state(db)
    with pytest.raises(BrokerVerificationError, match="Tool or arguments"):
        await VerifiedExecutionBroker(db).commit(
            decision.effect_certificate,
            CALL.model_copy(update={"tool_name": "suspend_vendor"}),
            AUTH,
        )
    assert await state(db) == before


async def test_expired_authentic_capability(db, monkeypatch):
    from packages.gate import capability

    decision, _ = await authorize(db)
    before = await state(db)
    monkeypatch.setattr(capability.time, "time", lambda: decision.effect_certificate.expires_at + 1)
    with pytest.raises(BrokerVerificationError, match="expired"):
        await VerifiedExecutionBroker(db).commit(decision.effect_certificate, CALL, AUTH)
    assert await state(db) == before


async def test_policy_revocation(db, tmp_path):
    from pathlib import Path
    from packages.policy.loader import PolicyLoader
    from packages.policy.compiler import PolicyCompiler

    p = tmp_path / "policy.yaml"
    p.write_text(Path("policies/reference.yaml").read_text())
    policy = PolicyCompiler(PolicyLoader(str(p)))
    predicted = await ShadowSimulator(db).predict(CALL)
    decision = NiyamGate(policy).evaluate(contract(), predicted, CALL, auth_context=AUTH)
    before = await state(db)
    p.write_text(p.read_text().replace('version: "1.0.0"', 'version: "revoked"'))
    with pytest.raises(BrokerVerificationError, match="Policy changed"):
        await VerifiedExecutionBroker(db, policy).commit(decision.effect_certificate, CALL, AUTH)
    assert await state(db) == before


async def test_phantom_row_after_issue_denied(db):
    decision, _ = await authorize(db)
    db.add(
        VendorInvoice(
            invoice_id="PHANTOM",
            vendor_id=4421,
            month=3,
            year=2025,
            amount_usd=1,
            status="OPEN",
            created_at="2025-03-01",
        )
    )
    await db.commit()
    before = await state(db)
    with pytest.raises(BrokerVerificationError, match="stale"):
        await VerifiedExecutionBroker(db).commit(decision.effect_certificate, CALL, AUTH)
    assert await state(db) == before


async def test_trigger_side_effect_rolls_back(db):
    from sqlalchemy import text
    from packages.storage.models import VendorCreditLimit, ConsumedCapability

    await db.execute(
        text(
            "CREATE TRIGGER corrupt_limit AFTER UPDATE OF status ON vendor_invoices BEGIN UPDATE vendor_credit_limits SET credit_limit_inr=credit_limit_inr+1; END"
        )
    )
    await db.commit()
    decision, _ = await authorize(db)
    before = await state(db)
    limits = list((await db.execute(select(VendorCreditLimit.credit_limit_inr))).scalars())
    with pytest.raises(BrokerVerificationError, match="actual database effects"):
        await VerifiedExecutionBroker(db).commit(decision.effect_certificate, CALL, AUTH)
    assert await state(db) == before
    assert list((await db.execute(select(VendorCreditLimit.credit_limit_inr))).scalars()) == limits
    assert list((await db.execute(select(ConsumedCapability))).scalars()) == []


async def test_crash_before_commit_rolls_back_effect_and_nonce(db):
    from packages.storage.models import ConsumedCapability
    from packages.storage.session import SessionManager

    before = await state(db)
    await db.rollback()
    with pytest.raises(RuntimeError, match="crash"):
        async with SessionManager(db).transaction():
            decision, _ = await authorize(db)
            await VerifiedExecutionBroker(db).commit(decision.effect_certificate, CALL, AUTH)
            raise RuntimeError("crash before commit")
    assert await state(db) == before
    assert list((await db.execute(select(ConsumedCapability))).scalars()) == []


async def test_batch_failure_rolls_back_first_tool(db):
    from packages.storage.models import ConsumedCapability
    from packages.storage.session import SessionManager

    before = await state(db)
    await db.rollback()
    with pytest.raises(BrokerVerificationError):
        async with SessionManager(db).transaction():
            decision, _ = await authorize(db)
            await VerifiedExecutionBroker(db).commit(decision.effect_certificate, CALL, AUTH)
            await VerifiedExecutionBroker(db).commit(
                decision.effect_certificate,
                CALL.model_copy(update={"tool_name": "delete_all"}),
                AUTH,
            )
    assert await state(db) == before
    assert list((await db.execute(select(ConsumedCapability))).scalars()) == []


async def test_concurrent_replay_exactly_one_commit(db):
    import asyncio
    from packages.storage.models import ConsumedCapability

    decision, _ = await authorize(db)
    await db.rollback()
    engine = db.bind

    async def attempt():
        async with AsyncSession(engine, expire_on_commit=False) as s:
            try:
                await VerifiedExecutionBroker(s).commit(decision.effect_certificate, CALL, AUTH)
                await s.commit()
                return "COMMITTED"
            except BrokerVerificationError as e:
                return str(e)

    outcomes = await asyncio.gather(attempt(), attempt())
    assert outcomes.count("COMMITTED") == 1
    assert any("Replay" in x for x in outcomes)
    assert len(list((await db.execute(select(ConsumedCapability))).scalars())) == 1
    archived = [r for r in await state(db) if r[5] == "ARCHIVED"]
    assert len(archived) == 3


@pytest.mark.parametrize(
    "raw",
    [
        "Archive March invoices for vendor 2025",
        "Archive March invoices with amount $2025 for vendor 4421",
        "Archive March 2025 or March 2026 invoices for vendor 4421",
    ],
)
async def test_calendar_year_requires_unambiguous_source(db, raw):
    decision, _ = await authorize(db, raw)
    assert decision.verdict in {"BLOCK", "CLARIFY"}
    assert decision.effect_certificate is None


async def test_supported_relative_month_has_trusted_reference(db):
    from datetime import datetime, UTC

    c = contract("Archive last month invoices for vendor 4421")
    c.reference_datetime = datetime(2025, 4, 1, tzinfo=UTC)
    delta = await ShadowSimulator(db).predict(CALL)
    decision = NiyamGate().evaluate(c, delta, CALL, auth_context=AUTH)
    assert decision.verdict == "ALLOW"


async def test_nonce_deleted_by_trigger_rolls_back(db):
    from sqlalchemy import text
    from packages.storage.models import ConsumedCapability

    await db.execute(
        text(
            "CREATE TRIGGER erase_nonce AFTER UPDATE OF status ON vendor_invoices BEGIN DELETE FROM consumed_capabilities; END"
        )
    )
    await db.commit()
    decision, _ = await authorize(db)
    before = await state(db)
    with pytest.raises(BrokerVerificationError, match="capability ledger"):
        await VerifiedExecutionBroker(db).commit(decision.effect_certificate, CALL, AUTH)
    assert await state(db) == before
    assert list((await db.execute(select(ConsumedCapability))).scalars()) == []


async def test_resealed_tampered_certificate_is_not_trusted(db):
    decision, _ = await authorize(db)
    before = await state(db)
    decision.effect_certificate.predicted_delta["record_ids"] = ["fake"]
    decision.effect_certificate.seal()
    with pytest.raises(BrokerVerificationError, match="origin"):
        await VerifiedExecutionBroker(db).commit(decision.effect_certificate, CALL, AUTH)
    assert await state(db) == before


async def test_concurrent_writer_cannot_add_phantom_inside_transaction(db):
    import sqlite3
    from packages.storage.session import SessionManager

    async with SessionManager(db).transaction():
        decision, _ = await authorize(db)
        conn = sqlite3.connect(db.bind.url.database, timeout=0)
        try:
            with pytest.raises(sqlite3.OperationalError, match="locked"):
                conn.execute(
                    "INSERT INTO vendor_invoices VALUES ('RACE',4421,3,2025,1,'OPEN','2025-03-01')"
                )
        finally:
            conn.close()
        delta = await VerifiedExecutionBroker(db).commit(decision.effect_certificate, CALL, AUTH)
        assert delta.estimated_row_count == 3
    assert all(row[0] != "RACE" for row in await state(db))


@pytest.mark.parametrize(
    "raw",
    [
        "Archive March invoices for vendor number 2025",
        "Archive March invoices for vendor 4421 with invoice ID INV-2025",
        "Archive March invoices for vendor 4421 with amount USD 2025",
        "వెండర్ 2025 మార్చి ఇన్వాయిస్లు ఆర్కైవ్ చేయండి",
    ],
)
async def test_year_must_have_positive_temporal_context(db, raw):
    decision, _ = await authorize(db, raw)
    assert decision.verdict in {"BLOCK", "CLARIFY"}


async def test_trigger_in_unmodeled_table_rolls_back(db):
    from sqlalchemy import text

    await db.execute(text("CREATE TABLE audit_log(id INTEGER PRIMARY KEY,message TEXT)"))
    await db.execute(
        text(
            "CREATE TRIGGER unexpected_insert AFTER UPDATE OF status ON vendor_invoices BEGIN INSERT INTO audit_log(message) VALUES ('unexpected'); END"
        )
    )
    await db.commit()
    decision, _ = await authorize(db)
    before = await state(db)
    with pytest.raises(BrokerVerificationError, match="unexpected inserted"):
        await VerifiedExecutionBroker(db).commit(decision.effect_certificate, CALL, AUTH)
    assert await state(db) == before
    assert (await db.execute(text("SELECT COUNT(*) FROM audit_log"))).scalar_one() == 0


@pytest.mark.parametrize(
    "raw",
    [
        "Archive March 2025 or 2026 invoices for vendor 4421",
        "Archive March 2025 and 2026 invoices for vendor 4421",
        "Archive March 2025-2026 invoices for vendor 4421",
    ],
)
async def test_shorthand_multiple_years_cannot_authorize_single_year(db, raw):
    decision, _ = await authorize(db, raw)
    assert decision.verdict in {"BLOCK", "CLARIFY"}


async def test_expiry_before_final_transaction_commit_rolls_back(db, monkeypatch):
    from packages.gate import capability
    from packages.storage.session import SessionManager

    before = await state(db)
    await db.rollback()
    with pytest.raises(BrokerVerificationError, match="expired"):
        async with SessionManager(db).transaction():
            decision, _ = await authorize(db)
            await VerifiedExecutionBroker(db).commit(decision.effect_certificate, CALL, AUTH)
            monkeypatch.setattr(
                capability.time, "time", lambda: decision.effect_certificate.expires_at + 1
            )
    assert await state(db) == before


async def test_policy_change_before_final_commit_rolls_back(db, tmp_path):
    from pathlib import Path
    from packages.storage.session import SessionManager
    from packages.policy.loader import PolicyLoader
    from packages.policy.compiler import PolicyCompiler

    p = tmp_path / "policy.yaml"
    p.write_text(Path("policies/reference.yaml").read_text())
    policy = PolicyCompiler(PolicyLoader(str(p)))
    before = await state(db)
    await db.rollback()
    with pytest.raises(BrokerVerificationError, match="Policy changed"):
        async with SessionManager(db).transaction():
            delta = await ShadowSimulator(db).predict(CALL)
            decision = NiyamGate(policy).evaluate(contract(), delta, CALL, auth_context=AUTH)
            await VerifiedExecutionBroker(db, policy).commit(
                decision.effect_certificate, CALL, AUTH
            )
            p.write_text(p.read_text().replace('version: "1.0.0"', 'version: "revoked"'))
    assert await state(db) == before
