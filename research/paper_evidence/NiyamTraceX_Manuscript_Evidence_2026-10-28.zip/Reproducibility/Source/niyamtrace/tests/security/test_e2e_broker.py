"""Native execution tests; public self-sealed fixtures no longer authorize writes."""

from sqlalchemy import update
import pytest
from packages.gate.broker import VerifiedExecutionBroker, BrokerVerificationError
from packages.auth.models import Principal, AuthorizationContext
from packages.storage.models import VendorInvoice
from tests.security.test_broker_adversarial_native import db, authorize, AUTH, CALL, state


async def test_broker_valid_execution(db):
    decision, expected = await authorize(db)
    actual = await VerifiedExecutionBroker(db).commit(decision.effect_certificate, CALL, AUTH)
    await db.commit()
    assert actual.record_id_set() == expected.record_id_set()
    assert actual.estimated_row_count == 3


async def test_broker_rejects_tampered_cert(db):
    decision, _ = await authorize(db)
    before = await state(db)
    decision.effect_certificate.actor = "user-hacker"
    with pytest.raises(BrokerVerificationError, match="integrity check failed"):
        await VerifiedExecutionBroker(db).commit(decision.effect_certificate, CALL, AUTH)
    assert await state(db) == before


async def test_broker_rejects_actor_mismatch(db):
    decision, _ = await authorize(db)
    wrong = AuthorizationContext.from_principal(
        Principal(subject="user-other", tenant_id="acme", roles=AUTH.roles, scopes=AUTH.scopes)
    )
    with pytest.raises(BrokerVerificationError, match="Actor identity mismatch"):
        await VerifiedExecutionBroker(db).commit(decision.effect_certificate, CALL, wrong)


async def test_broker_rejects_state_mismatch(db):
    decision, _ = await authorize(db)
    await db.execute(
        update(VendorInvoice)
        .where(VendorInvoice.invoice_id == "INV-4421-2503")
        .values(status="PAID")
    )
    await db.commit()
    before = await state(db)
    with pytest.raises(BrokerVerificationError, match="State mismatch"):
        await VerifiedExecutionBroker(db).commit(decision.effect_certificate, CALL, AUTH)
    assert await state(db) == before
