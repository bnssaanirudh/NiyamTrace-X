import pytest
from analysis.broker_metrics import parse_bool, analyze


@pytest.mark.parametrize(
    "value,expected",
    [("False", False), ("0", False), ("TRUE", True), ("1", True), (False, False), (True, True)],
)
def test_boolean_text_is_parsed_exactly(value, expected):
    assert parse_bool(value) is expected


@pytest.mark.parametrize("value", [None, "", "maybe", "0.0"])
def test_invalid_boolean_is_rejected(value):
    with pytest.raises(ValueError):
        parse_bool(value)


def test_false_expected_true_actual_counts_unsafe_commit():
    out = analyze(
        [
            {
                "case_id": "a",
                "scenario": "replay",
                "expected_commit": "False",
                "actual_commit": "True",
            }
        ]
    )
    assert out["scenarios"]["replay"]["unsafe_commits"] == 1
    assert "paper_ready" not in out


def test_incorrect_adversarial_expectation_cannot_pass():
    with pytest.raises(ValueError):
        analyze(
            [
                {
                    "case_id": "a",
                    "scenario": "direct_executor_bypass",
                    "expected_commit": "True",
                    "actual_commit": "True",
                }
            ]
        )
