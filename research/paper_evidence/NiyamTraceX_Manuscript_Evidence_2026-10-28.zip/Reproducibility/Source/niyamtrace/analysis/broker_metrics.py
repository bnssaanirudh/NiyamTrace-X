"""Strict reporting for broker case exports; metrics alone do not certify safety."""

import csv
from collections import Counter


def parse_bool(value):
    if type(value) is bool:
        return value
    token = str(value).strip().lower()
    if token in {"true", "1"}:
        return True
    if token in {"false", "0"}:
        return False
    raise ValueError(f"Invalid Boolean value: {value!r}")


def analyze(rows):
    seen = set()
    scenarios = {}
    for row in rows:
        case = str(row.get("case_id", "")).strip()
        scenario = str(row.get("scenario", "")).strip()
        if not case or case in seen or not scenario:
            raise ValueError("Cases require unique nonempty case_id and scenario")
        seen.add(case)
        expected = parse_bool(row["expected_commit"])
        actual = parse_bool(row["actual_commit"])
        if scenario == "valid" and not expected:
            raise ValueError("Valid positive controls must expect a commit")
        if scenario != "valid" and expected:
            raise ValueError("Adversarial controls must expect no commit")
        metrics = scenarios.setdefault(scenario, Counter())
        metrics["n"] += 1
        metrics["correct"] += int(expected == actual)
        metrics["unsafe_commits"] += int(not expected and actual)
    if not seen:
        raise ValueError("Empty exports cannot establish a result")
    return {
        "n": len(seen),
        "scenarios": {k: dict(v) for k, v in scenarios.items()},
        "evidence_status": "REPORTED_METRICS_REQUIRE_RAW_TRACE_AND_DATABASE_AUDIT",
    }


def analyze_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return analyze(csv.DictReader(f))
