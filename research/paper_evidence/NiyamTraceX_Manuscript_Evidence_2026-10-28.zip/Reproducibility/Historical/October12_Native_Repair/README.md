# NiyamTrace-X — Native broker repair and verified experiments

## Start here

Open **20_NTX_NATIVE_BROKER_REPAIR_AND_ADVERSARIAL_COLAB.ipynb** in Google Colab, choose a CPU runtime and use **Run all**. No uploads, Drive mount, GPU or paid API key are needed. The notebook downloads a pinned public repository and installs dependencies, so internet is required.

## Already verified

- Full canonical repository suite: **361 passed, 1 existing skip, 0 failures**.
- Native adversarial security regressions: **34 passed**.
- Retained native evidence probes: **9/9 passed**; the valid archive changes precisely three intended invoices; eight negative probes change no database rows.
- SQLite migration upgrade and downgrade verified.
- Source base and patch hashes recorded; raw logs, traces and before/after SQLite files included.

The source repair is committed locally on `codex/broker-security-closure`; it has not been pushed to GitHub. The supplied unified patch applies to the recorded base commit. The notebook embeds the same changed files and verifies original hashes before applying them. It then makes a local source commit and produces `NTX20_NATIVE_BROKER_VERIFIED_RESULTS.zip`.

## Contents

- Standalone Colab notebook with the source patch embedded.
- `NiyamTraceX_Broker_Security_Repair.patch` — reviewable production-source and test changes.
- `native_evidence/` — nine actual source probe runs with SQLite before/after files, JSONL traces, effects and hashes.
- `verification_logs/` — original baseline, reproduced failures, final test logs and JUnit output.
- Source manifests, exact dependency versions, independent code review and limitations.
- `VERIFY_RETAINED_EVIDENCE.py` — standard-library verifier for the retained artifacts.

## Research boundary

These are synthetic engineering experiments using controlled extraction fixtures, not live-model or human-request benchmark results. They repair and exercise invoice archiving. Other write handlers and authenticated approval execution remain disabled/incomplete; PostgreSQL deployment was not tested. Prospective human collection, formal signoff, live-model experiments and official guarded agent benchmarks remain required for broader paper claims.

Notebook code syntax, embedded source hashes and patch application were checked locally. The local tests used Python 3.12; this environment did not execute Google Colab itself.
