# NiyamTrace-X native broker security repair

Base repository commit: `651e87ef452c80008d4f73c8f2de21321e21fa50`.

## Scope

This patch repairs the repository's invoice-archiving execution path. It is source-level engineering evidence from SQLite and controlled extraction fixtures. It does not establish live-model multilingual accuracy, official AgentDojo/tau-bench performance, PostgreSQL deployment correctness, or study approval.

## Changes

- Public SHA-256 self-sealing remains an audit operation; gate-issued HMAC authentication is separately required to execute.
- Certificates bind the verified principal context, tenant, exact tool call, complete predicted effects, current policy hash, nonce and expiry.
- Both ERPExecutor and the registered invoice implementation reject execution outside the broker's active authorization context.
- The gateway's transaction now encompasses simulation, authorization and all writes. A separate certificate is used for each tool call.
- SQLite obtains a write lock before simulation; capability consumption and business effects share the same commit/rollback.
- A persistent nonce primary key prevents replay across broker instances. SQLAlchemy commit hooks recheck expiry, policy and nonce presence at the final commit boundary.
- The broker audits actual changes across reflected physical database tables, including tables outside ORM metadata and the capability ledger. Unexpected inserts, deletes, fields or values roll back.
- Original request text must positively ground its year through a calendar expression. Supported monthly relative expressions require a trusted reference datetime. Missing, identity-derived, amount-derived, invoice-ID-derived and multiple-year scopes fail closed.
- Unimplemented vendor-suspension, credit-limit and user-block handlers are explicitly rejected by the executor. Approval tickets cannot silently turn an escalation into an unsigned execution authorization.
- CSV Boolean parsing uses explicit true/false/1/0 values; strings such as `False` cannot become truthy values. Metric reports do not automatically certify paper readiness.

## Tests and evidence

The initial five native regressions produced four failures on the original source. The legacy mocked broker suite passed despite the vulnerabilities. New regressions use real SQLite state and native gate/broker/executor code. They cover origin forgery, direct calls, wrong actors/tenants/roles/tools/arguments, expiry, policy changes, replay, concurrency, phantom rows, trigger effects, ledger corruption, crash rollback, batch rollback and request grounding. Independent review identified additional calendar-context and unmodeled-table gaps; their reproductions were retained and repaired.

Complete-request test fixtures were updated to state a year explicitly. Mock extraction fixtures preserve explicit years rather than inventing the current year. Previous executor effect assertions now execute through genuine gate authorization. The pre-existing stale assertion requiring five gate checks was corrected to verify all eight named policy checks. Original human requests, labels and published pilot result files were not modified or rescored.

The native evidence runner retains before/after SQLite files, JSONL traces, per-file hashes and source hashes for nine synthetic probes. The missing-year fixture deliberately proposes a model-filled year and tests its rejection. No live model is called.

## Apply and run

Use the supplied standalone Colab notebook on a CPU runtime. It downloads the pinned baseline, verifies original file hashes, applies the embedded patch, runs tests, creates a local source commit, executes native evidence probes and downloads the result archive. No upload, Drive mount or paid API key is required. A fresh folder is created for every run.

For an existing deployment, back up the database and apply the added Alembic migration before enabling the broker. Fresh test databases are initialized through Base.metadata. Migration upgrade/downgrade was verified on SQLite.

Production configuration requires `NIYAM_CAPABILITY_KEY` with at least 32 bytes, held by the trusted server and shared consistently among its workers. Development uses a process-local random key; capabilities from a previous process cannot be reused. Keep issuer key access inside the trusted server boundary.

## Material limits

- Arbitrary Python code with server memory/key access, or raw database credentials, is outside this threat model.
- Full physical-table snapshots are suitable for the research fixture; scalability on large databases remains unmeasured.
- Calendar grounding is deliberately conservative. A calendar-anchored request containing an additional unexplained year-like value requests clarification rather than dropping the value.
- The three other business write handlers and authenticated approval execution remain incomplete; these routes fail closed. Execution-effect claims should be restricted to invoice archiving.
- PostgreSQL SERIALIZABLE support is present but was not executed in this environment.
- Prospective consented human data, faculty/ethics signoff, live-model comparisons and official guarded agent benchmarks remain separate completion requirements.
