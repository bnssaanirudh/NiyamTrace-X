"""Independently verify retained hashes, SQLite contents and test accounting."""
from pathlib import Path
import hashlib,json,sqlite3,xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
NATIVE=ROOT/'native_evidence'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def snapshot(path):
    with sqlite3.connect(path) as db:
        assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
        tables=[r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        result={}
        for table in tables:
            quoted='"'+table.replace('"','""')+'"'
            columns=[r[1] for r in db.execute('PRAGMA table_info('+quoted+')')]
            result[table]=sorted([dict(zip(columns,row)) for row in db.execute('SELECT * FROM '+quoted)],key=lambda row:json.dumps(row,sort_keys=True))
        return result

report=json.loads((NATIVE/'PRODUCTION_FIX_EVIDENCE.json').read_text())
summary=json.loads((ROOT/'VERIFICATION_SUMMARY.json').read_text())
assert report['repo_commit']==summary['patched_local_commit']
assert report['working_tree_dirty'] is False
manifest=json.loads((NATIVE/'SHA256_MANIFEST.json').read_text())
for rel,expected in manifest.items():assert sha(NATIVE/rel)==expected,rel
expected_ids={'INV-4421-2503','INV-4421-2504','INV-4421-2505'}
for probe in report['probes']:
    assert probe['status']=='PASS'
    for field,path_field in [('trace_sha256','trace_path'),('before_db_sha256','before_db_path'),('after_db_sha256','after_db_path')]:
        assert sha(NATIVE/probe[path_field])==probe[field]
    before=snapshot(NATIVE/probe['before_db_path']);after=snapshot(NATIVE/probe['after_db_path'])
    if probe['id']=='SEC-04_PAIRED_BROKER_POSITIVE':
        assert probe['decision']=='ALLOW'
        old={row['invoice_id']:row for row in before['vendor_invoices']}
        new={row['invoice_id']:row for row in after['vendor_invoices']}
        changed={key for key in old if old[key]!=new[key]}
        assert changed==expected_ids
        for key in changed:
            assert old[key]['status']=='OPEN' and new[key]['status']=='ARCHIVED'
            assert {k:v for k,v in old[key].items() if k!='status'}=={k:v for k,v in new[key].items() if k!='status'}
        for table in before:
            if table not in {'vendor_invoices','consumed_capabilities'}:assert before[table]==after[table]
        assert before['consumed_capabilities']==[] and len(after['consumed_capabilities'])==1
    else:
        assert probe['decision'] in {'BLOCK','CLARIFY'}
        assert before==after,probe['id']
        assert probe['rows_mutated']==0
xml=ET.parse(ROOT/'verification_logs/full_suite_junit.xml')
cases=xml.findall('.//testcase')
failed=[c for c in cases if c.find('failure') is not None or c.find('error') is not None]
skipped=[c for c in cases if c.find('skipped') is not None]
assert len(cases)-len(skipped)-len(failed)==361
assert len(failed)==0 and len(skipped)==1
native_cases=[c for c in cases if c.attrib.get('classname','').endswith('test_broker_adversarial_native')]
assert len(native_cases)==34
print('Verified: 9 native probes, 18 SQLite snapshots, all artifact hashes, 361 test passes, 34 native regressions.')
